<?php
/**
 * User: Oleg Prihodko
 * Mail: shuru@e-mind.ru
 * Date: 14.11.2014
 * Time: 12:33
 */
namespace app\modules\admin;
class Module extends \yii\base\Module {

} 
