<h4>Admin</h4>
<a href="/admin/connects">Connects</a><br/>
<a href="/admin/installs">Installs</a><br/>
<a href="/admin/finishes">Finishes</a><br/>
<a href="/admin/offers">Offers</a><br/>
<h4>Publisher</h4>
<a href="/publisher/offers">Offers</a><br/>
