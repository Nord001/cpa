<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\search\InstallerInstallsSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Installer Installs';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="installer-installs-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Installer Installs', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'click_id',
            'user_id',
            'soft_name',
            'guid',
            // 'hdd_serial_number',
            // 'soft_id',
            // 'date_created',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>

</div>
