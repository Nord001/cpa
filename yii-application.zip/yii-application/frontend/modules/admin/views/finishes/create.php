<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\InstallerFinishes */

$this->title = 'Create Installer Finishes';
$this->params['breadcrumbs'][] = ['label' => 'Installer Finishes', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="installer-finishes-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
