<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\search\InstallerFinishesSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="installer-finishes-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'click_id') ?>

    <?= $form->field($model, 'user_id') ?>

    <?= $form->field($model, 'soft_name') ?>

    <?= $form->field($model, 'guid') ?>

    <?php // echo $form->field($model, 'hdd_serial_number') ?>

    <?php // echo $form->field($model, 'softs_id') ?>

    <?php // echo $form->field($model, 'date_created') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
