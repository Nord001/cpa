<?php

namespace app\modules\admin\controllers;

use Yii;
use yii\web\Controller;

/**
 * ConnectsController implements the CRUD actions for InstallerConnects model.
 */
class DefaultController extends Controller {

	public function actionIndex () {
		return $this->render('index');
	}
}
