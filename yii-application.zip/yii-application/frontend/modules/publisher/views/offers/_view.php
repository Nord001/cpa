<?
/**
 * @var $model Offers
 */
use app\models\Offers;
use yii\helpers\Url;

?>
<tr>
	<td>
		<span class="bold theme-font"><?= $model->id ?></span>
	</td>
	<td class="fit">
<!--		<img src="--><?////= $model->image ?><!--" class="">-->
	</td>
	<td>
		<a class="primary-link" href="<?= URL::to(
			[
				"offers/view",
				"id" => $model->id
			]
		) ?>"><?= $model->name ?></a>
	</td>
	<td style="width: 15%;">
		<?//= $model->about ?>
	</td>
	<td>
		$<?//= number_format($model->max_price, 2) ?>
	</td>
	<td>
		<span class="bold theme-font"><?//= $model->countries ?></span>
	</td>
	<td>
		<span<?= !$model->is_fix_countries
			?' class="label label-sm label-success"'
			:' class="label label-sm label-warning"' ?>>
			<?= $model->is_fix_countries
				?'Yes'
				:'No' ?></span>
	</td>
	<td>
		<span<?= !$model->is_partial_install
			?' class="label label-sm label-success"'
			:' class="label label-sm label-warning"' ?>>
			<?= $model->is_partial_install
				?'Yes'
				:'No' ?></span>
	</td>
</tr>
