<?php

use yii\helpers\Html;
use yii\widgets\ListView;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title                   = 'Offers';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="row">
	<div class="col-md-12">
		<!-- BEGIN SAMPLE TABLE PORTLET-->
		<div class="portlet light">
			<div class="portlet-title">
				<div class="caption">
					<i class="fa fa-cogs font-green-sharp"></i>
					<span class="caption-subject font-green-sharp bold uppercase">My offers</span>
				</div>
			</div>

			<?= ListView::widget(
				[
					'dataProvider' => $dataProvider,
//					'itemOptions'  => ['class' => 'item'],
					'itemView'     => '_view',
//					'options'      => ['class' => "table-scrollable table-scrollable-borderless"],
					'layout'       => '
				                                    <table class="table table-hover table-light">
				                                        <thead>
				                                            <tr class="uppercase">
				                                                    <th>
				                                                        Offer ID
				                                                    </th>
				                                                    <th colspan="2">
				                                                        Offer name
				                                                    </th>
				                                                    <th>
				                                                        About
				                                                    </th>
				                                                    <th>
				                                                        Lead cost
				                                                    </th>
				                                                    <th>
				                                                        Countries
				                                                    </th>
				                                                    <th>
				                                                        Only fix countries
				                                                    </th>
				                                                    <th>
				                                                        Partial install
				                                                    </th>
				                                            </tr>
				                                        </thead>
				                                        {items}
				                                    </table>
				                                    {pager}
				                            ',
				]
			) ?>

		</div>
		<!-- END SAMPLE TABLE PORTLET-->
	</div>
</div>
<?
/**
 * TODO: в таблице вывести странцы, цену, название, онли фикс, партиал инсталл,
 * TODO: сделать лэндинги, вывести их в карточке оффера
 * TODO: сделать валюты
 * TODO: сделать описание у оффера
 * TODO: сделать список стран
 * TODO: сделать таблицу связей оффера со странами
 */
