<?php

/* @var $this yii\web\View */
use yii\helpers\Url;

/**
 * @var array $data
 */
$this->title = 'Offers';
$this->params['breadcrumbs'][] = [
	'label' => 'Offers',
	'url'   => ['index']
];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="row">
	<div class="col-md-12">
		<div class="portlet light">
			<div class="row">
				<div class="col-md-8">
					<div class="portlet light">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-cogs font-green-sharp"></i>
								<span class="caption-subject font-green-sharp bold uppercase">Offer landings</span>
							</div>
						</div>
						<div class="table-scrollable table-scrollable-borderless">
							<table class="table table-hover table-light">
								<thead>
								<tr class="uppercase">
									<th>
										Landing ID
									</th>
									<th>
										Landing
									</th>
									<th>
										Url
									</th>
								</tr>
								</thead>
								<tbody>
								<?php
									foreach($data['landings'] as $landing) {
										?>
										<tr>
											<td>
												<span class="bold theme-font"><?= $landing['id'] ?></span>
											</td>
											<td>
												<?= $landing['url'] ?>
											</td>
											<td>
												<input type="text" class="form-control" style="width: 350px; border: 0; background: #eee;" value="http://<?=\yii::$app->params['redirectURL'];?>?landing=<?=$landing['id'];?>&pubid=224&keyword=test" />
											</td>
										</tr>
									<?php
									}
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="portlet light">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-cogs font-green-sharp"></i>
								<span class="caption-subject font-green-sharp bold uppercase">Offer information</span>
							</div>
						</div>
						<div class="table-scrollable table-scrollable-borderless">
							<div class="well">
								<div class="row static-info align-reverse">
									<div class="col-md-4 name">
										Offer ID:
									</div>
									<div class="col-md-8 value">
										<?= $model->id ?>
									</div>
								</div>
								<div class="row static-info align-reverse">
									<div class="col-md-4 name">
										Active:
									</div>
									<div class="col-md-8 value">

									</div>
								</div>
								<div class="row static-info align-reverse">
									<div class="col-md-4 name">
										Description:
									</div>
									<div class="col-md-8 value">
									</div>
								</div>
								<div class="row static-info align-reverse">
									<div class="col-md-4 name">
										Price:
									</div>
									<div class="col-md-8 value">
									</div>
								</div>
								<div class="row static-info align-reverse">
									<div class="col-md-4 name">
										Countries:
									</div>
									<div class="col-md-8 value">
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>
