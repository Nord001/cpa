<?php
use app\models\ConversionsStat;
use yii\web\View;

/* @var $this View */
/* @var $model ConversionsStat */
$this->params['breadcrumbs'][] = "Reports";
//Yii::app()->clientScript->registerScriptFile("/publishers/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js", CClientScript::POS_END);
?>
<div class="row">
	<div class="col-md-12">
		<!-- BEGIN PORTLET-->
		<div class="portlet box blue-hoki">
			<div class="portlet-title">
				<div class="caption">
					<i class="fa fa-gift"></i>Reports settings
				</div>
				<div class="tools">
					<a class="collapse" href="javascript:;">
					</a>
				</div>
			</div>
			<div class="portlet-body form">
				<form class="form-horizontal form-bordered" id="yw0" action="/stats/index" method="get">
					<div class="form-group">
						<label class="col-sm-3 control-label" for="ConversionsStat_dt">Dt</label>

						<div class="col-sm-3">
							<div class="input-group">
												<span class="input-group-addon">
												<i class="fa fa-calendar-o "></i>
												</span>
												<span class="twitter-typeahead"
													  style="position: relative; display: inline-block; direction: ltr;">
													<input class="form-control tt-input"
														   id="ConversionsStat_dt_from"
														   name="ConversionsStat[dt_from]" type="text"/>                                            </span>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="input-group">
												<span class="input-group-addon">
												<i class="fa fa-calendar-o "></i>
												</span>
												<span class="twitter-typeahead"
													  style="position: relative; display: inline-block; direction: ltr;">
													<input class="form-control tt-input" id="ConversionsStat_dt_to"
														   name="ConversionsStat[dt_to]" type="text"/>                                            </span>
							</div>
						</div>
					</div>
					<div class="form-actions">
						<div class="row">
							<div class="col-md-offset-3 col-md-9">
								<button class="btn purple" type="submit"><i class="fa fa-check"></i> Search</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
		<!-- END PORTLET-->
	</div>
	<div class="col-md-12">
		<!-- BEGIN SAMPLE TABLE PORTLET-->
		<div class="portlet light">
			<div class="portlet-title">
				<div class="caption">
					<i class="fa fa-cogs font-green-sharp"></i>
					<span class="caption-subject font-green-sharp bold uppercase">Conversions stats</span>
				</div>
			</div>
			<div class="table-scrollable table-scrollable-borderless" id="conversions-stat-grid">

				<table class="table table-striped table-bordered table-hover dataTable no-footer">
					<thead>
					<tr class='heading'>
						<th id="conversions-stat-grid_c0">
							<a class="sort-link" href="/stats/index?ConversionsStat_sort=dt">Dt</a>
						</th>
						<th id="conversions-stat-grid_c1">
							<a class="sort-link" href="/stats/index?ConversionsStat_sort=ip">Ip</a>
						</th>
						<th id="conversions-stat-grid_c2">
							<a class="sort-link" href="/stats/index?ConversionsStat_sort=country">Country</a>
						</th>
						<th id="conversions-stat-grid_c3">
							<a class="sort-link" href="/stats/index?ConversionsStat_sort=install">Install</a>
						</th>
						<th id="conversions-stat-grid_c4">
							<a class="sort-link" href="/stats/index?ConversionsStat_sort=success">Success</a>
						</th>
					</tr>
					<tr class="filter">
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
					</tr>
					</thead>
					<tbody>
					<tr>
						<td colspan="5" class="empty"><span class="empty">No results found.</span></td>
					</tr>
					</tbody>
				</table>

			</div>
		</div>
	</div>
</div>
<script type="text/javascript" src="/publishers/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="/publishers/global/plugins/bootstrap-datepicker/css/datepicker3.css" />
<script type="text/javascript">
	$('#conversions-stat-grid').click(function () {
		$('#conversions-stat-grid').yiiGridView('update', {
			data: $(this).serialize()
		});
		return false;
	});
	//$('.date-picker').datepicker({
	//    rtl: Metronic.isRTL(),
	//    autoclose: true
	//});

	jQuery('#ConversionsStat_dt_from').datepicker([]);
	jQuery('#ConversionsStat_dt_to').datepicker([]);

	Metronic.init(); // init metronic core componets
	//        Layout.init(); // init layout
	//        Demo.init(); // init demo(theme settings page)
	//        Index.init(); // init index page
	//        Tasks.initDashboardWidget(); // init tash dashboard widget
</script>


