<?php
/* @var $this \yii\web\View */
use common\models\LoginForm;
use yii\widgets\ActiveForm;

/* @var $model LoginForm */
/* @var $form ActiveForm */

$form = ActiveForm::begin(
	[
		'id'          => 'login-form',
		'fieldConfig' => [
			'template'     => '
				<div class="form-group">
					{label}
					<div class="input-icon">
						<i class="fa fa-user"></i>
						{input}
					</div>
					{error}
				</div>
			',
			'labelOptions' => [
				'class' => 'control-label visible-ie8 visible-ie9'
			],
			'errorOptions' => [
				'class' => 'help-block'
			],
			'inputOptions' => [
				'class' => 'form-control placeholder-no-fix'
			]
		]
	]
);
?>

<h3 class="form-title">Login to your account</h3>
<?php
if (!empty($model->errors)) {
	foreach($model->errors as $error) {
		?>
		<div class="alert alert-danger display-hide">
			<button class="close" data-close="alert"></button>
			<span>
			<?= $error ?> </span>
		</div>
	<?php
	}
}
?>
<?= $form->field($model, 'username')->textInput(
	[
		"placeholder" => "Email"
	]
);
?>

<?= $form->field($model, 'password')->passwordInput(
	[
		"placeholder" => "Password"
	]
);
?>

<div class="form-actions">
	<label class="checkbox">
		<input type="checkbox" name="LoginForm[rememberMe]" value="1"/> Remember me </label>
	<button type="submit" class="btn green pull-right">
		Login <i class="m-icon-swapright m-icon-white"></i>
	</button>
</div>
<div class="forget-password">
	<h4>Forgot your password ?</h4>

	<p>
		no worries, click <a href="javascript:;" id="forget-password">
			here </a>
		to reset your password.
	</p>
</div>
<div class="create-account">
	<p>
		Don't have an account yet ?&nbsp; <a href="javascript:;" id="register-btn">
			Create an account </a>
	</p>
</div>
<?php ActiveForm::end() ?>
<!-- END LOGIN FORM -->
<!-- BEGIN FORGOT PASSWORD FORM -->
<form class="forget-form" action="index.html" method="post">
	<h3>Forget Password ?</h3>
	<p>
		Enter your e-mail address below to reset your password.
	</p>

	<div class="form-group">
		<div class="input-icon">
			<i class="fa fa-envelope"></i>
			<input class="form-control placeholder-no-fix" type="text" autocomplete="off" placeholder="Email"
				   name="email"/>
		</div>
	</div>
	<div class="form-actions">
		<button type="button" id="back-btn" class="btn">
			<i class="m-icon-swapleft"></i> Back
		</button>
		<button type="submit" class="btn green pull-right">
			Submit <i class="m-icon-swapright m-icon-white"></i>
		</button>
	</div>
</form>
<!-- END FORGOT PASSWORD FORM -->
<!-- BEGIN REGISTRATION FORM -->
<form class="register-form" action="index.html" method="post">
	<h3>Sign Up</h3>

	<p>
		Enter your personal details below:
	</p>

	<div class="form-group">
		<label class="control-label visible-ie8 visible-ie9">Full Name</label>

		<div class="input-icon">
			<i class="fa fa-font"></i>
			<input class="form-control placeholder-no-fix" type="text" placeholder="Full Name" name="fullname"/>
		</div>
	</div>
	<div class="form-group">
		<!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
		<label class="control-label visible-ie8 visible-ie9">Email</label>

		<div class="input-icon">
			<i class="fa fa-envelope"></i>
			<input class="form-control placeholder-no-fix" type="text" placeholder="Email" name="email"/>
		</div>
	</div>
	<div class="form-group">
		<label class="control-label visible-ie8 visible-ie9">Password</label>

		<div class="input-icon">
			<i class="fa fa-lock"></i>
			<input class="form-control placeholder-no-fix" type="password" autocomplete="off" id="register_password"
				   placeholder="Password" name="password"/>
		</div>
	</div>
	<div class="form-group">
		<label class="control-label visible-ie8 visible-ie9">Re-type Your Password</label>

		<div class="controls">
			<div class="input-icon">
				<i class="fa fa-check"></i>
				<input class="form-control placeholder-no-fix" type="password" autocomplete="off"
					   placeholder="Re-type Your Password" name="rpassword"/>
			</div>
		</div>
	</div>
	<div class="form-group">
		<label>
			<input type="checkbox" name="tnc"/> I agree to the <a href="#">
				Terms of Service </a>
			and <a href="#">
				Privacy Policy </a>
		</label>

		<div id="register_tnc_error">
		</div>
	</div>
	<div class="form-actions">
		<button id="register-back-btn" type="button" class="btn">
			<i class="m-icon-swapleft"></i> Back
		</button>
		<button type="submit" id="register-submit-btn" class="btn green pull-right">
			Sign Up <i class="m-icon-swapright m-icon-white"></i>
		</button>
	</div>
</form>
