<?
use yii\helpers\Url;
?>
<!-- BEGIN HEADER -->
<div class="page-header">
    <div class="page-header-top">
        <div class="container">
            <div class="page-logo">
                <a href="/"><img src="/img/logo.png" alt="logo" class="logo-default"></a>
            </div>
            <a href="javascript:;" class="menu-toggler"></a>
            <div class="top-menu">
            <ul class="nav navbar-nav pull-right">
            <!-- BEGIN NOTIFICATION DROPDOWN -->
            <li class="dropdown dropdown-extended dropdown-dark dropdown-notification" id="header_notification_bar">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                    <i class="icon-bell"></i>
                    <span class="badge badge-default">7</span>
                </a>
                <ul class="dropdown-menu">
                    <li class="external">
                        <h3>You have <strong>12 pending</strong> tasks</h3>
                        <a href="#">view all</a>
                    </li>
                    <li>
                        <ul class="dropdown-menu-list scroller" style="height: 250px;" data-handle-color="#637283">
                            <li>
                                <a href="#">
                                    <span class="time">just now</span>
										<span class="details">
										<span class="label label-sm label-icon label-success">
										<i class="fa fa-plus"></i>
										</span>
										New user registered. </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="time">3 mins</span>
										<span class="details">
										<span class="label label-sm label-icon label-danger">
										<i class="fa fa-bolt"></i>
										</span>
										Server #12 overloaded. </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="time">10 mins</span>
										<span class="details">
										<span class="label label-sm label-icon label-warning">
										<i class="fa fa-bell-o"></i>
										</span>
										Server #2 not responding. </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="time">14 hrs</span>
										<span class="details">
										<span class="label label-sm label-icon label-info">
										<i class="fa fa-bullhorn"></i>
										</span>
										Application error. </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="time">2 days</span>
										<span class="details">
										<span class="label label-sm label-icon label-danger">
										<i class="fa fa-bolt"></i>
										</span>
										Database overloaded 68%. </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="time">3 days</span>
										<span class="details">
										<span class="label label-sm label-icon label-danger">
										<i class="fa fa-bolt"></i>
										</span>
										A user IP blocked. </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="time">4 days</span>
										<span class="details">
										<span class="label label-sm label-icon label-warning">
										<i class="fa fa-bell-o"></i>
										</span>
										Storage Server #4 not responding dfdfdfd. </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="time">5 days</span>
										<span class="details">
										<span class="label label-sm label-icon label-info">
										<i class="fa fa-bullhorn"></i>
										</span>
										System Error. </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="time">9 days</span>
										<span class="details">
										<span class="label label-sm label-icon label-danger">
										<i class="fa fa-bolt"></i>
										</span>
										Storage server failed. </span>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
            <!-- END INBOX DROPDOWN -->
            <!-- BEGIN USER LOGIN DROPDOWN -->
            <li class="dropdown dropdown-user dropdown-dark">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                    <!--        <img alt="" class="img-circle" src="/publishers/admin/layout3/img/avatar9.jpg">-->
                    <span class="username username-hide-mobile">Nick</span>
                </a>
                <ul class="dropdown-menu dropdown-menu-default">
                    <li>
                        <a href="extra_profile.html">
                            <i class="icon-user"></i> My Profile </a>
                    </li>
                    <li>
                        <a href="inbox.html">
                            <i class="icon-envelope-open"></i> My Inbox <span class="badge badge-danger">
								3 </span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="icon-rocket"></i> My Tasks <span class="badge badge-success">
								7 </span>
                        </a>
                    </li>
                    <li class="divider">
                    </li>
                    <li>
                        <a href="/logout">
                            <i class="icon-key"></i> Log Out </a>
                    </li>
                </ul>
            </li>
            <!-- END USER LOGIN DROPDOWN -->
            </ul>
            </div>
        </div>
    </div>
    <div class="page-header-menu">
        <div class="container">
            <div class="hor-menu ">
            <ul class="nav navbar-nav">
                <li<?=(Yii::$app->controller->route == "publisher/default/dashboard")?' class="active"':''?>>
                    <a href="<?=URL::to(["default/dashboard"])?>">Dashboard</a>
                </li>
                <li class="menu-dropdown mega-menu-dropdown<?=(Yii::$app->controller->id == "offer")?' active':''?>">
                    <a data-hover="megamenu-dropdown" data-close-others="true" data-toggle="dropdown" href="javascript:;" class="dropdown-toggle hover-initialized">
                        Offers <i class="fa fa-angle-down"></i>
                    </a>
                    <ul class="dropdown-menu" style="min-width: 710px">
                        <li>
                            <div class="mega-menu-content">
                                <div class="row">
                                    <div class="col-md-4">
                                        <ul class="mega-menu-submenu">
                                            <li>
                                                <a href="<?=URL::to(["offer/index"])?>" class="iconify">
                                                    <i class="icon-home"></i>
                                                    Offers </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="menu-dropdown mega-menu-dropdown<?=(Yii::$app->controller->id == "stats")?' active':''?>">
                    <a data-hover="megamenu-dropdown" data-close-others="true" data-toggle="dropdown" href="javascript:;" class="dropdown-toggle hover-initialized">
                        Reports <i class="fa fa-angle-down"></i>
                    </a>
                    <ul class="dropdown-menu" style="min-width: 710px">
                        <li>
                            <div class="mega-menu-content">
                                <div class="row">
                                    <div class="col-md-4">
                                        <ul class="mega-menu-submenu">
                                            <li>
                                                <a href="<?=URL::to(["stats/index"])?>" class="iconify">
                                                    <i class="icon-home"></i>
                                                    Stats </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <!-- end: mega menu with custom content -->
            </ul>
            </div>
        </div>
    </div>
    <!-- END HEADER MENU -->
</div>
