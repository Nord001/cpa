<?php

namespace app\modules\publisher\controllers;

use common\models\LoginForm;
use yii\web\Controller;

class DefaultController extends Controller {
	public $layout = '//publisher';
	public function behaviors () {
		return parent::behaviors();
//		return [
//			'access' => [
//				'class' => AccessControl::className(),
//				'only'  => [
//					'index',
//					'dashboard',
//				],
//				'rules' => [
//					[
//						'actions' => ['index'],
//						'allow'   => true,
//						'roles'   => ['guest'],
//					],
//					[
//						'actions' => ['dashboard'],
//						'allow'   => true,
//						'roles'   => ['publisher'],
//					],
//				],
//			],
//		];
	}

	public function actionDashboard () {
		return $this->render("dashboard");
	}

	public function actionIndex () {
		$this->layout = '/publisher_login';
//		if (!\Yii::$app->user->getIsGuest()) {
//			$this->redirect("/dashboard");
//			\yii::$app->end();
//		}
//		$this->layout = "//layouts/publisher_login";
		$model        = new LoginForm;
//		$model->type  = 'publisher';
//		// if it is ajax validation request
//		if (isset($_POST['ajax']) && $_POST['ajax']==='login-form') {
//			echo CActiveForm::validate($model);
//			Yii::app()->end();
//		}
//		// collect user input data
//		if (isset($_POST['LoginForm'])) {
//			$model->attributes = $_POST['LoginForm'];
//			// validate user input and redirect to the previous page if valid
//			if ($model->validate() && $model->login()) {
//				$this->redirect(Yii::app()->user->returnUrl);
//			}
//		}
		// display the login form
		return $this->render('login', array ('model' => $model));
	}
}
