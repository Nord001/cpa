<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of StatsController
 *
 * @author YC-php
 */
namespace app\modules\publisher\controllers;

use app\models\ConversionsStat;
use yii\web\Controller;

class StatsController extends Controller{
    public $layout = "//publisher";
    public function actionIndex(){
        $model = new ConversionsStat();
        $model->affiliate_id = \yii::$app->user->id;
        if(isset($_GET['ConversionsStat'])){
            $model->load($_GET['ConversionsStat']);
        }
        return $this->render('index',array(
            'model'=>$model,
        ));
    }
    //put your code here
}
