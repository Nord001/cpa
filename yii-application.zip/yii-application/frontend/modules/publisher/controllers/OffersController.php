<?php

namespace app\modules\publisher\controllers;

use app\models\Offers;
use Yii;
use app\models\search\OffersSearch;
use app\modules\publisher\components\searchlists\offers\View;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * OfferController implements the CRUD actions for Offer model.
 */
class OffersController extends Controller {

	public $layout = 'main';

	public function behaviors () {
		return [
			'verbs' => [
				'class'   => VerbFilter::className(),
				'actions' => [
					'delete' => ['post'],
				],
			],
		];
	}

	/**
	 * Lists all Offer models.
	 * @return mixed
	 */
	public function actionIndex () {
		$searchModel  = new OffersSearch();
		$dataProvider = $searchModel->search(Yii::$app->request->queryParams);
		return $this->render(
			'index',
			[
				'dataProvider' => $dataProvider,
			]
		);
	}

	/**
	 * Displays a single Offer model.
	 * @param integer $id
	 * @return mixed
	 */
	public function actionView ($id) {
		return $this->render(
			'view',
			[
				'data' => (new View())->setParams(['offer_id' => $id])->getResults()
			]
		);
	}

	/**
	 * Finds the Offer model based on its primary key value.
	 * If the model is not found, a 404 HTTP exception will be thrown.
	 * @param integer $id
	 * @return Offer the loaded model
	 * @throws NotFoundHttpException if the model cannot be found
	 */
	protected function findModel ($id) {
		if (($model = Offers::findOne($id))!==null) {
			return $model;
		} else {
			throw new NotFoundHttpException('The requested page does not exist.');
		}
	}
}
