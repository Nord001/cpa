<?php
namespace app\modules\publisher\components\searchlists\offers;
use app\components\SearchListAbstract;
use app\models\Landings;
use app\models\Offers;

class View extends SearchListAbstract {

	protected $params = [
		'offer_id' => null,
	];
//	protected $results = [
//		'landings'   => [],
//		'offer_info' => null,
//	];

	/**
	 * TODO: делать валидатор для каждого searchlist'а
	 */

	/**
	 * Процесс поиска и заполнение его результатами аттрибута results
	 */
	protected function loadResults () {
		$this->results['offer_info'] = Offers::find($this->params['offer_id'])->asArray()->one();
		$this->results['landings'] = Landings::find()->asArray()->all();
	}

	/**
	 * Процесс выяснения общего количества результатов поиска без учета лимитов и запись числа в аттрибут total_count
	 */
	protected function loadTotalCount () {
		$this->totalCount = 1;
	}
}
