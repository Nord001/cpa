<?php

namespace app\modules\redirect\controllers;

use app\modules\redirect\components\Redirect;
use app\modules\redirect\components\RedirectException;
use yii\helpers\Url;
use yii\web\Controller;

class DefaultController extends Controller {

	const URL_REJECT = '/api/reject';

	public function actionIndex () {
		try {
			(new Redirect())
				->getParams()
				->checkParams()
				->setLog()
				->goRedirect();
		} catch(RedirectException $e) {
			echo "<pre>";
			print_r($e->getMessage());
			echo "</pre>";
			die();
			\yii::$app->response->redirect(URL::to(self::URL_REJECT));
		}
	}

	public function actionReject () {
	}
}
