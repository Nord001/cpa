<?php

namespace app\modules\redirect;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\redirect\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
