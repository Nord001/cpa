<?php
/**
 * User: Oleg Prihodko
 * Mail: shuru@e-mind.ru
 * Date: 20.11.2014
 * Time: 16:12
 */


namespace app\modules\redirect\components;

class RedirectException extends \Exception{

} 
