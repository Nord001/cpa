<?php
/**
 * User: Oleg Prihodko
 * Mail: shuru@e-mind.ru
 * Date: 20.11.2014
 * Time: 15:57
 */
namespace app\modules\redirect\components;

use app\components\loggers\TextLogger;
use app\components\validators\ValidationException;
use app\models\Landings;
use app\modules\redirect\components\validators\RedirectValidator;

class Redirect {

	private $params = [];
	const ALPHABER_CLICKID = 'QqWwEeRrTtYyUuIiOoPpaAsSdDFfGgHhJjKkLlZzXxCcVvBbNnMm1234567890';

	public function getParams () {
		$this->getRequestParams();
		$this->addExtendsParams();
		return $this;
	}

	public function checkParams () {
		try {
			(new RedirectValidator())->setParams($this->params)->validate();
			return $this;
		} catch (ValidationException $e){
			throw new RedirectException($e->getMessage());
		}
	}

	public function setLog () {
		(new RedirectLog)->addLogger(new TextLogger())->setParams($this->params)->run();
		return $this;
	}

	public function goRedirect () {
		$url = $this->getLanding()['url'].'?'.http_build_query($this->params);
		\yii::$app->response->redirect($url);
		return $this;
	}

	public function getLanding () {
		$landing = Landings::findOne($this->params['landing']);
		return $landing;
	}

	private function getRequestParams () {
		$this->params = \yii::$app->request->get();
	}

	private function addExtendsParams () {
		$this->params['referrer'] = \yii::$app->request->referrer;
		$this->params['ip']       = \yii::$app->request->userIP;
		$this->params['clickid']  = $this->clickIdGenerate();

	}

	private function clickIdGenerate ($length = 8) {
		$length_need = min($length, strlen(self::ALPHABER_CLICKID));
		$result      = '';
		while(strlen($result) < $length) {
			$result .= substr(str_shuffle(self::ALPHABER_CLICKID), 0, $length_need);
		}  // *
		return $result;
	}
}
