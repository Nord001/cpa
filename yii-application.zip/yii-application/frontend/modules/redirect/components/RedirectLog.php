<?php
namespace app\modules\redirect\components;

use app\components\loggers\LoggerInterface;

class RedirectLog {
	private $params = [];
	private $loggers = [];
	public function addLogger (LoggerInterface $logger) {
		$this->loggers[] = $logger;
		return $this;
	}

	public function setParams (array $params) {
		$this->params = $params;
		return $this;
	}

	public function run () {

	}

} 
