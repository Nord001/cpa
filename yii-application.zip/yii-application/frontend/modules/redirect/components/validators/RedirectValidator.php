<?php
namespace app\modules\redirect\components\validators;

use app\components\validators\ValidatorAbstract;
use app\components\validators\ValidatorInterface;
use app\models\Landings;

class RedirectValidator extends ValidatorAbstract implements ValidatorInterface{

	/**
	 * Правила валидации
	 * @return array
	 */
	public function rules () {
		return [
			[['landing', 'pubid', 'keyword'], 'require'],
			[['landing'], 'object', 'app\models\Landings'],
			[['pubid'], 'object', 'app\models\Users'],
			[['subid1','subid2','subid3','subid4','subid5',], 'string', 'max'=>255],
		];
	}
}
