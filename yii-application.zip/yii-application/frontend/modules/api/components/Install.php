<?php
namespace app\modules\api\components;

use app\models\InstallerInstalls;

class Install extends InstallerAbstract {

	protected $_requestType = 'install';

	public function setLog () {
		$log                    = new InstallerInstalls();
		$log->click_id          = $this->_requestParams['click_id'];
		$log->user_id           = $this->_requestParams['user_id'];
		$log->soft_name         = $this->_requestParams['soft_name'];
		$log->guid              = $this->_requestParams['GUID'];
		$log->hdd_serial_number = $this->_requestParams['SerialNum'];
		$log->soft_id           = $this->_requestParams['InstallProgramID'];
		$log->save(false);
	}
}
