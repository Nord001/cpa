<?php
namespace app\modules\api\components;
/**
 * User: Oleg Prihodko
 * Mail: shuru@e-mind.ru
 * Date: 19.11.2014
 * Time: 14:04
 */
class Crypt {

	private $_decodeString;
	private $_encodeString;
	public static $_instance;

	private function __construct () {
	}

	public static function model () {
		if (empty(self::$_instance)) {
			self::$_instance = new self;
		}
		return self::$_instance;
	}

	public function setEncodeString ($string) {
		$this->_encodeString = $string;
		return $this;
	}

	public function replaceChars ($search, $replace) {
		$this->_encodeString = str_replace($search, $replace, $this->_encodeString);
		return $this;
	}

	public function decrypt () {
		$string = base64_decode($this->_encodeString);
		$string = strrev($string);
		$path   = dirname(__FILE__).'/private.pem';
		$privatekey = openssl_pkey_get_private(file_get_contents($path), "");
		if (!$privatekey) {
			throw new InstallerException('Не найден приватный ключ.');
		}
		if (!openssl_private_decrypt($string, $res, $privatekey)) {
			var_dump($this->_encodeString);
			throw new InstallerException('Не удалось расшифровать запрос.');
		}
		$this->_decodeString = $res;
		return $this;
	}

	public function getArgs () {
		$out = array ();
		if (!empty($this->_decodeString)) {
			$args = explode("&", $this->_decodeString);
			if (!empty($args)) {
				foreach($args as $arg) {
					$params = explode("=", $arg);
					if (count($params)==2) {
						$out[$params[0]] = $params[1];
					}
				}
			}
		}
		return $out;
	}
} 
