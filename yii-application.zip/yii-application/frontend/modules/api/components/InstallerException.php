<?php
namespace app\modules\api\components;

class InstallerException extends \Exception {

}
