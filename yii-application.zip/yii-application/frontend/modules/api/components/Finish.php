<?php
namespace app\modules\api\components;

use app\models\InstallerFinishes;

class Finish extends InstallerAbstract {

	protected $_requestType = 'finish';

	public function getSoftsId () {
		$softs = [];
		foreach($this->_requestParams as $key=>$item) {
			if(preg_match('/^Software\[\d+?\]$/',$key)) {
				$softs[] = $item;
				unset($this->_requestParams[$key]);
			}
		}
		$this->_requestParams['softs_id'] = implode(',',$softs);
	}

	public function setLog () {
		$log                    = new InstallerFinishes();
		$log->click_id          = $this->_requestParams['click_id'];
		$log->user_id           = $this->_requestParams['user_id'];
		$log->soft_name         = $this->_requestParams['soft_name'];
		$log->guid              = $this->_requestParams['GUID'];
		$log->hdd_serial_number = $this->_requestParams['SerialNum'];
		$log->softs_id          = $this->_requestParams['softs_id'];
		$log->save(false);
	}
}
