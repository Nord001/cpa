<?php
namespace app\modules\api\components;

use app\models\InstallerConnects;

class Connect extends InstallerAbstract {

	protected $_requestType = 'connect';

	public function createNameOfResponseFile () {
		$this->_nameOfResponseFile = $this->_requestParams['soft_name'];
	}

	public function createSoftList () {
		$this->_sponsoredSoftList = [
			[
				'name'        => 'First.txt',
				'link'        => 'http://maxppi.com/css/form.css',
				'params'      => 'empty',
				'description' => 'By clicking "Next & Install" I agree to the <A HREF="http://downloadtrace.com/terms.php#policy?q='.$this->_nameOfResponseFile.'">Privacy Policy</A> and consent to install First',
				'img'         => 'http://3.bp.blogspot.com/-TFC3kwxxO9U/T5Y8XYF2FLI/AAAAAAAAEic/4e3_nH8Fqy0/s1600/Program.png',
				'view_type'   => 0,
				'id'          => 2
			],
			[
				'name'        => 'Second.txt',
				'link'        => 'http://maxppi.com/css/form.css',
				'params'      => 'empty',
				'description' => 'By clicking "Next", I agree to the <A HREF="http://downloadtrace.com/terms.php?q='.$this->_nameOfResponseFile.'">Terms Of Service and privacy</A> and consent to the install Second',
				'img'         => 'http://icons.iconarchive.com/icons/treetog/i/256/Set-Program-Default-icon.png',
				'view_type'   => 0,
				'id'          => 1
			]
		];
	}

	public function getResponse () {
		$this->setHeader();
		return $this->getContent();
	}

	public function setHeader () {
		header("Expires: Sun, 1 Jan 2000 12:00:00 GMT");
		header("Cache-Control: no-store, no-cache, must-revalidate");
		header("Cache-Control: post-check=0, pre-check=0", false);
		header("Pragma: no-cache");
		header("Content-Type: text/html; charset=utf-8");
	}

	public function getContent () {
		$out = $this->_nameOfResponseFile.'|http://google.com/|http://downloadtrace.com/|'.sizeof($this->_sponsoredSoftList).'|';
		foreach($this->_sponsoredSoftList as $item) {
			$out .= $item['name'].'|'.$item['link'].'|'.$item['params'].'|'.$item['description'].'|'.$item['img'].'|'.$item['view_type'].'|'.$item['id'].'|';
		}
		return $out;
	}

	public function setLog () {
		$log                        = new InstallerConnects();
		$log->click_id              = $this->_requestParams['click_id'];
		$log->user_id               = $this->_requestParams['user_id'];
		$log->soft_name             = $this->_nameOfResponseFile;
		$log->guid                  = $this->_requestParams['GUID'];
		$log->hdd_serial_number     = $this->_requestParams['SerialNum'];
		$log->net_framework_version = $this->_requestParams['NetFrameworkVersion'];
		$log->os_version            = $this->_requestParams['OS_Version'];
		$log->count_softs           = sizeof($this->_sponsoredSoftList);
		$log->save(false);
	}
}
