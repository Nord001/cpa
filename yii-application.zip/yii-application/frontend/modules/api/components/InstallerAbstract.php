<?php
namespace app\modules\api\components;

abstract class InstallerAbstract {

	protected $_request;
	protected $_requestParams;
	protected $_nameOfResponseFile;
	protected $_sponsoredSoftList;
	protected $_requestType;

	abstract public function setLog ();

	public function validateRequest () {
		if (!$this->_request = \yii::$app->request->post('encrypt')) {
			throw new InstallerException('Пустой запрос.');
		}
	}

	public function decryptRequest () {
		$this->_requestParams	= Crypt::model()
									->setEncodeString($this->_request)
									->replaceChars(array ("|"),array ("+"))
									->decrypt()
									->getArgs();
		$this->_requestParams['ProgramName'] = explode('_', $this->_requestParams['ProgramName']);
		$this->_requestParams['soft_name']   = $this->_requestParams['ProgramName'][0];
		$this->_requestParams['click_id']    = $this->_requestParams['ProgramName'][1];
		$this->_requestParams['user_id']     = $this->_requestParams['ProgramName'][2];

	}
}
