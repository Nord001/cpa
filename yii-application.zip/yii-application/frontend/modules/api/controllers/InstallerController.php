<?php

namespace app\modules\api\controllers;

use app\modules\api\components\Connect;
use app\modules\api\components\Finish;
use app\modules\api\components\Install;
use yii\web\Controller;

class InstallerController extends Controller {
	public $enableCsrfValidation = false;

	public function actionConnect () {
		try {
			$connect = new Connect();
			$connect->validateRequest();
			$connect->decryptRequest();
			$connect->createSoftList();
			$connect->createNameOfResponseFile();
			$connect->setLog();
			echo $connect->getResponse();
		} catch (\Exception $e){
			file_put_contents(dirname(__FILE__).'/logs/errors.connect.txt', date('d.m.Y H:i:s').':'.$e->getMessage()."\r\n",FILE_APPEND);
			\yii::$app->end();
		}
	}

	public function actionInstall () {
		try {
			$install = new Install();
			$install->validateRequest();
			$install->decryptRequest();
			$install->setLog();
		} catch (\Exception $e){
			file_put_contents(dirname(__FILE__).'/logs/errors.installs.txt', date('d.m.Y H:i:s').':'.$e->getMessage()."\r\n",FILE_APPEND);
			\yii::$app->end();
		}
	}

	public function actionFinish () {
		try {
			$finish = new Finish();
			$finish->validateRequest();
			$finish->decryptRequest();
			$finish->getSoftsId();
			$finish->setLog();
		} catch (\Exception $e){
			file_put_contents(dirname(__FILE__).'/logs/errors.finishes.txt', date('d.m.Y H:i:s').':'.$e->getMessage()."\r\n",FILE_APPEND);
			\yii::$app->end();
		}
	}


}
