<?php

$config = [
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'lYitShKtMS59lpTL-qK-HU4cj1OcbSPf',
        ],
		'urlManager'   => [
			'enablePrettyUrl' => true,
			'showScriptName'  => false,
			'rules'           => [
//				"site/page/<view:\w+>"                                                      => "site/page",
//				"site/page/<view:\w+>/"                                                     => "site/page",
//				'http://<module:\w+>.'.$params['rootURL']                                   => '<module>/default/index',
//				'http://<module:\w+>.'.$params['rootURL'].'/<controller:\w+>'               => '<module>/<controller>/index',
//				'http://<module:\w+>.'.$params['rootURL'].'/<controller:\w+>/'              => '<module>/<controller>/index',
//				'http://<module:\w+>.'.$params['rootURL'].'/<controller:\w+>/<id:\d+>'      => '<module>/<controller>/view',
//				'http://<module:\w+>.'.$params['rootURL'].'/<controller:\w+>/<id:\d+>/'     => '<module>/<controller>/view',
//				'http://<module:\w+>.'.$params['rootURL'].'/<controller:\w+>/<action:\w+>'  => '<module>/<controller>/<action>',
//				'http://<module:\w+>.'.$params['rootURL'].'/<controller:\w+>/<action:\w+>/' => '<module>/<controller>/<action>',
			],
		],
    ],
];

if (!YII_ENV_TEST) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = 'yii\debug\Module';

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = 'yii\gii\Module';
}

return $config;
