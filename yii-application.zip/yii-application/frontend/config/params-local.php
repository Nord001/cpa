<?php
return [
//	'rootURL'     => 'maxppi.com',
//	'redirectURL' => 'redirect.maxppi.com',
];
