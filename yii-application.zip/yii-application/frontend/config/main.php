<?php
$params = array_merge(
	require(__DIR__.'/../../common/config/params.php'),
	require(__DIR__.'/../../common/config/params-local.php'),
	require(__DIR__.'/params.php'),
	require(__DIR__.'/params-local.php')
);
return [
	'id'                  => 'app-frontend',
	'basePath'            => dirname(__DIR__),
	'bootstrap'           => ['log'],
	'controllerNamespace' => 'frontend\controllers',
	'components'          => [
		'user'         => [
			'identityClass'   => 'common\models\User',
			'enableAutoLogin' => true,
		],
		'log'          => [
			'traceLevel' => YII_DEBUG
				?3
				:0,
			'targets'    => [
				[
					'class'  => 'yii\log\FileTarget',
					'levels' => [
						'error',
						'warning'
					],
				],
			],
		],
		'errorHandler' => [
			'maxSourceLines' => 20,
		],
		'urlManager'   => [
			'enablePrettyUrl' => true,
			'showScriptName'  => false,
			'rules'           => [
				"site/page/<view:\w+>"          => "site/page",
				"<module:\w+>"                  => "<module>/default/index",
				"<module:\w+>/<controller:\w+>" => "<module>/<controller>/index",
			],
		],
	],
	'modules'             => [
		'publisher' => [
			'class' => 'app\modules\publisher\Module',
		],
		'admin'     => [
			'class' => 'app\modules\admin\Module',
		],
		'redirect'  => [
			'class' => 'app\modules\redirect\Module',
		],
		'api'       => [
			'class' => 'app\modules\api\Module',
		],
	],
	'params'              => $params,
];
