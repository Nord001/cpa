<?php
return [
	'adminEmail'  => 'admin@example.com',
	'redirectURL' => 'lb008.gateap.com/redirect/',
	'rootURL'     => 'lb008.gateap.com',
];
