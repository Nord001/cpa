<?php
/**
 * Created by PhpStorm.
 * User: shuru_000
 * Date: 18.11.2014
 * Time: 16:18
 */
namespace app\components\validators;

interface ValidatorInterface {

	/**
	 * Сеттер для параметров
	 * @param array $params
	 * @return ValidatorInterface
	 */
	public function setParams (array $params);

	/**
	 * Валидация
	 * @return bool
	 */
	public function validate ();
} 
