<?php
namespace app\components\validators;

abstract class ValidatorAbstract implements ValidatorInterface {

	private $params;

	/**
	 * Правила валидации
	 * @return array
	 */
	abstract public function rules();

	/**
	 * Сеттер параметров
	 * @param array $params
	 * @return ValidatorAbstract
	 */
	public function setParams (array $params) {
		$this->params = $params;
		return $this;
	}

	public function validate () {
		foreach($this->rules() as $validator) {
			if(!isset($validator[1])) {
				throw new ValidationException('Неверно сконфигурированы правила валидации');
			}
			$methodName = 'validator'.ucfirst($validator[1]);
			if(!method_exists($this, $methodName)) {
				throw new ValidationException('Не найдено определение для валидатора "'.$validator[1].'"');
			}

			$extends = !isset($validator[2]) ? null : $validator[2];

			foreach($validator[0] as $param) {
				$this->$methodName($param, $extends);
			}
		}
	}

	/**
	 * @param $name
	 * @throws ValidationException
	 */
	private function validatorRequire ($name) {
		if(!isset($this->params[$name])) {
			throw new ValidationException('Параметр '.$name.' не найден');
		}
		if(empty($this->params[$name])) {
			throw new ValidationException('Параметр '.$name.' должен содержать некоторое значение');
		}
	}

	public function validatorObject ($name, $className){
		if(!$className::findOne($this->params[$name])) {
			throw new ValidationException('Не найден объект "'.$className.'" со значением '.$this->params[$name]);
		}
	}

	public function validatorString ($name, $length) {
		if(isset($this->params[$name])) {
			if(strlen($this->params[$name])>$length) {
				throw new ValidationException('Длина параметра '.$name.' превышает '.$length);
			}
		}
	}
}

class ValidationException extends \Exception{

}
