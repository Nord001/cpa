<?php
namespace app\components\loggers;

interface LoggerInterface {

} 
