<?php
namespace app\components\loggers;

class TextLogger implements LoggerInterface{

} 
