<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "softs".
 *
 * @property integer $id
 * @property integer $user_id
 * @property string $date_created
 * @property boolean $is_active
 * @property integer $platform_id
 * @property integer $country_id
 * @property integer $limit_per_day
 * @property string $date_close
 *
 * @property Users $user
 * @property InstallerInstalls[] $installerInstalls
 */
class Softs extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'softs';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id', 'platform_id', 'country_id', 'limit_per_day'], 'integer'],
            [['date_created', 'date_close'], 'safe'],
            [['is_active'], 'boolean']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'ID рекламодателя',
            'date_created' => 'Дата создания',
            'is_active' => 'Активен ли софт',
            'platform_id' => 'ID платформы',
            'country_id' => 'ID страны',
            'limit_per_day' => 'Лимит в день, null - без лимита',
            'date_close' => 'Дата закрытия, null - дата отсутствует',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(Users::className(), ['id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getInstallerInstalls()
    {
        return $this->hasMany(InstallerInstalls::className(), ['soft_id' => 'id']);
    }
}
