<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

/**
 * This is the model class for table "landings".
 *
 * @property integer       $id
 * @property string        $url
 * @property integer       $country_id
 * @property integer       $platform_id
 * @property string        $date_created
 *
 * @property ProfitStats[] $profitStats
 */
class Landings extends ActiveRecord {

	/**
	 * @inheritdoc
	 */
	public static function tableName () {
		return 'landings';
	}

	/**
	 * @inheritdoc
	 */
	public function rules () {
		return [
			[['url', 'country_id', 'platform_id'], 'required'],
			[['country_id', 'platform_id'], 'integer'],
			[['date_created'], 'safe'],
			[['url'], 'string', 'max' => 255]
		];
	}

	/**
	 * @inheritdoc
	 */
	public function attributeLabels () {
		return [
			'id'           => 'ID',
			'url'          => 'URL лэндинга',
			'country_id'   => 'ID страны',
			'platform_id'  => 'ID платформы',
			'date_created' => 'Дата создания',
		];
	}

	/**
	 * @return \yii\db\ActiveQuery
	 */
	public function getProfitStats () {
		return $this->hasMany(ProfitStats::className(), ['landing_id' => 'id']);
	}
}
