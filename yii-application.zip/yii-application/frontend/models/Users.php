<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

/**
 * This is the model class for table "users".
 *
 * @property integer      $id
 * @property string       $login
 * @property string       $password
 * @property integer      $role
 * @property string       $date_created
 *
 * @property Publishers[] $publishers
 */
class Users extends ActiveRecord {

	/**
	 * @inheritdoc
	 */
	public static function tableName () {
		return 'users';
	}

	/**
	 * @inheritdoc
	 */
	public function rules () {
		return [
		  	[['login', 'password', 'role'], 'required'],
		  	[['role'], 'integer'],
		  	[['date_created'], 'safe'],
		  	[['login', 'password'], 'string', 'max' => 255]
	  	];
	}

	/**
	 * @inheritdoc
	 */
	public function attributeLabels () {
		return [
			'id'           => 'ID',
			'login'        => 'Имя пользователя',
			'password'     => 'Хэш пароля',
			'role'         => 'Роль',
			'date_created' => 'Дата создания',
		];
	}

	/**
	 * @return \yii\db\ActiveQuery
	 */
	public function getPublishers () {
		return $this->hasMany(Publishers::className(), ['user_id' => 'id']);
	}
}
