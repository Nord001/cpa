<?php
/**
 * @var $this View
 */
use yii\web\View;

$this->context->topTitle = "About us";
$this->context->topText = "Learn more about MAXPPI.";
?>
<div class="row">
    <div class="span11 offset1">
        <h2>MAX PPI provides a unique marketplace and technology platform which introduces software users to new software products they may be interested in.</h2>
        <p>While offering users the opportunity to explore new software products, MAX PPI provides its advertisers with access to new, exclusive markets and customer-bases. All of this is done with our innovative, open-market concept that drives thousands of software installations every day while still serving the interests of all parties involved.</p>
        <p>
            MAX PPI’s team consists of highly experiences online-marketing and technology personnel, specializing in SEM, affiliate marketing, media buying, social network marketing, software installer technology and various monetization solutions.
        </p>
        <p>
            On top of that, we offer our own software network, focused on generating new clients for our advertisers and, at the same time, monetizing the distribution of other software applications. We work with a several free software titles and bundle them with matching offers for the publisher’s audience. We work directly with all of our partners and are proud to cooperate directly with industry leaders such as CNET, Google, Softonic, Tucows, and more.
        </p>
        <p>
            MAX PPI offers solutions for application developers and web publishers with one simple goal in mind – to get great software applications in front of customers. All of the software applications in our marketplaces are screened and tested before they ever get offered to a customer. Our state-of-the-art MAX PPI installer is tuned to find and match the best possible software to the targeted user.
        </p>
        <p>
            <b>Application developers require customers, advertisers are constantly looking to expand their user-base, web publishers need to monetize their site and content, and consumers seek someone to lead them through the chaos to great applications. We are here to connect them all and make sure all parties reach their goals.</b>
        </p>
    </div>
</div>
