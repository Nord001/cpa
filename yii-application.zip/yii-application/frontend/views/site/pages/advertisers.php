<?php
/**
 * @var $this View
 */
use yii\web\View;

$this->context->topTitle = "Advertisers";
?>
<div class="row">
    <div class="span11 offset1">
        <div class="row">
            <div class="span7">
                <h1>MAX PPI is the ultimate Pay-Per-Install (PPI) network for serious advertisers!</h1>
                <br />
                <p>MAX PPI offers an advanced PPI optimization platform which enables PPI distribution and monetization. We help advertisers find the most effective way to advertise online and create successful internet marketing campaigns. Our goal: maximize our partners’ advertising revenues.</p>
                <p>
                    MAX PPI advertisers are software providers who wish to attract new distribution partners, additional targeted users and a wider install base.
                </p>
                <p>
                    MAX PPI offers its advertisers an advanced Pay-Per-Install optimization platform which enables PPI distribution and monetization.
                </p>
                <p>
                    We work with top-quality software products that generate thousands of daily installs worldwide. We find the ones that are most suitable for your target audience and offer these users the opportunity to install your product. Together, we will raise your conversion numbers through optimal exposure and services to your targeted audiences.
                </p>
                <h2>MAX PPI  Pay-Per-Install features:</h2>
                <ul>
                    <li>You can create your campaign in minutes!</li>
                    <li>You can choose your preferred geographic targeting.</li>
                    <li>You pay only for the verified installs you receive.</li>
                    <li>You can monitor your campaigns’ performance online.</li>
                    <li>We provide with round-the-clock protection against any fraud.</li>
                    <li>Campaigns can be limited to a maximum number of daily verified installations.</li>
                    <li>Personal dedicated media adviser for each advertiser.</li>
                </ul>
            </div>
            <div class='span4'>
                <img src='/img/publisher-banner.jpg'/>
            </div>
        </div>
    </div>
</div>
