<?php
/**
 * @var $this View
 */
use yii\web\View;

$this->context->topTitle = "Publishers";
?>
<div class="row">
    <div class="span11 offset1">
        <div class="row">
            <div class="span7">
                <h1>MAX PPI is the ultimate way to earn money any time someone installs your software product!</h1>
                <br />
                <p>MAX PPI publishers are software developers who wish to gain additional revenues by offering add-on software products to users who are already installing their product.</p>
                <p>MAX PPI offers it’s publishers an advanced Pay-Per-Install optimization platform that allows them to get maximum income each time a user installs their software product. We work with top-quality advertisers that complement your own software offerings and bring additional value to your users. Together we will raise your revenues through the optimal exposure of products and services to your user-base.</p>
                <p>Our unique partnership program was invented to aid you in achieving the most out of your software installations, in addition to providing you with a secure and steady stream of income! With MAX PPI your free software installations will be turned into cash.</p>
                <br />
                <h2>MAX PPI Pay-Per-Installation Benefits:</h2>
                <ul class='publisher-page-list'>
                    <li>You will get paid for every install.</li>
                    <li>You will always get the highest payouts.</li>
                    <li>You can control what additional software product you will be promoting</li>
                    <li>You will provide additional value for your users with each installation</li>
                    <li>You will provided with  detailed installations activity  reports</li>
                    <li>And you will receive prompt payments.</li>
                </ul>
            </div>
            <div class='span4'>
                <img src='/img/publisher-banner.jpg'/>
            </div>
        </div>
    </div>
</div>
