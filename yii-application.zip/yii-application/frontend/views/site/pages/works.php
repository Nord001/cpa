<?php
/**
 * @var $this View
 */
use yii\web\View;

$this->context->topTitle = "How it Works";
$this->context->topText = "How does MAXPPI make things happen?";
?>
<div class="row">
    <div class="span11 offset1">
        <div class="row">
            <div class="span11">
                <h3>MAXPPI provides a unique marketplace & technology platform that introduces software’s users to new software<br /> products which they may be interested in.</h3>
                <br />
                <p>We provide our own installer software component. Our installer easily integrates with any Windows software product. The installer component offers users which are installing one of our software partners’ products, the opportunity to install some of our advertisers’ software in addition to that installation.</p>
                <p>
                    We provide our own installer software component. Our installer easily integrates with any Windows software product. The installer component offers users which are installing one of our software partners’ products, the opportunity to install some of our advertisers’ software in addition to that installation.
                </p>
                <p>
                    The exact additional software offering our installer offers is determined by our sophisticated ad server back-office technology, taking into consideration the users’ profile, the advertisers’ targeting parameters and the software publishers’ restrictions.
                </p>
                <p>
                   All of this assists users in gaining more value from their software installation while helping the software author make much more money from the product installation and helping our advertisers boost their ROI and expand their user base and targeted audience. 
                </p>
                <p>
                    Software publishers can sign up for a publisher account with MAXPPI. After a review and approval process, their account will be assigned to one of our experienced account managers who will then contact them and guide them through integration.
                </p>
                <p>
                    After the software publisher integrates our installer, he then receives his own login details to our back-office reporting system, after which he can start distributing his application along with our integrated installer and start making money with MAXPPI.
                </p>
                <p>
                    MAXPPI’s experienced team will work closely with you in order to boost your performance and provide you with the best possible solution for you needs.
                </p>
            </div>
        </div>
    </div>
</div>
