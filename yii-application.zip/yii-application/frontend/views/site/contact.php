<?php
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\captcha\Captcha;

$this->context->topTitle = "Contact";
$this->context->topText  = "Send a message to the MAX PPI team";
?>
<?php
/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\ContactForm */

$this->title = Yii::$app->name.' - Contact Us';
\yii\widgets\Breadcrumbs::widget(
	[
		'links' => ['Contact',]
	]
);
?>
<div class="row">
	<div class="span5 offset3">
		<?php if (Yii::$app->session->hasFlash('contact')): ?>

			<div class="alert alert-success">
				<?php echo Yii::$app->session->getFlash('contact'); ?>
			</div>

		<?php else: ?>

			<?php $form = ActiveForm::begin(
				[
					'id'          => 'contact-form',
					'options'     => [
						'class'                  => "form-horizontal",
						'enableClientValidation' => true,
					],
					'fieldConfig' => [
						'template' => '
							<div class="control-group">
								<div>
									{label}
								</div>
								<div class="controls">
									{input}
								</div>
							</div>
						'
					]
				]
			); ?>
			<?php if (!empty($model->errors)) { ?>
				<div class="errorSummary">
					<?php echo $form->errorSummary($model); ?>
				</div>
			<?php } ?>
			<?= $form->field($model, 'name'); ?>
			<?= $form->field($model, 'email'); ?>
			<?= $form->field($model, 'subject')->textarea(
				[
					'size'      => 60,
					'maxlength' => 128,
					"class"     => 'span5'
				]
			); ?>
			<?= $form->field($model, 'body')->textarea(
				[
					'rows'  => 6,
					'cols'  => 50,
					"class" => 'span5'
				]
			); ?>


			<?php if (Captcha::checkRequirements()): ?>
				<div class="control-group">
					<?= $form->field($model, 'verifyCode')->widget(
						Captcha::className(),
						[
							'template' => '
						<div class="controls">
							{image}
						</div>
						<div class="controls">
							{input}
						</div>
						',
						]
					) ?>
				</div>
			<?php endif; ?>

			<div class="control-group">
				<?php echo Html::submitButton(
					'Send',
					array (
						'class' => 'btn btn-large btn-success',
						'style' => 'float: right;'
					)
				); ?>
			</div>
			<?php ActiveForm::end() ?>
		<?php endif; ?>
	</div>
</div>
