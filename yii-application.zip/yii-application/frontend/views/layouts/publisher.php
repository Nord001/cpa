<?
/**
 * @var $this View
 */
use yii\helpers\Html;
use yii\web\View;
use yii\widgets\Breadcrumbs;

?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
    <meta charset="utf-8">
    <title><?php echo Html::encode($this->title); ?></title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css">
    <link href="/publishers/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="/publishers/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css">
    <link href="/publishers/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="/publishers/global/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css">
    <!-- END GLOBAL MANDATORY STYLES -->
    <!-- BEGIN PAGE LEVEL PLUGIN STYLES -->
    <link href="/publishers/global/plugins/jqvmap/jqvmap/jqvmap.css" rel="stylesheet" type="text/css">
    <link href="/publishers/global/plugins/morris/morris.css" rel="stylesheet" type="text/css">
    <!-- END PAGE LEVEL PLUGIN STYLES -->
    <!-- BEGIN PAGE STYLES -->
    <link href="/publishers/admin/pages/css/tasks.css" rel="stylesheet" type="text/css"/>
    <!-- END PAGE STYLES -->
    <!-- BEGIN THEME STYLES -->
    <link href="/publishers/global/css/components.css" rel="stylesheet" type="text/css">
    <link href="/publishers/global/css/plugins.css" rel="stylesheet" type="text/css">
    <link href="/publishers/admin/layout3/css/layout.css" rel="stylesheet" type="text/css">
    <link href="/publishers/admin/layout3/css/themes/default.css" rel="stylesheet" type="text/css" id="style_color">
    <link href="/publishers/admin/layout3/css/custom.css" rel="stylesheet" type="text/css">

	<script src="/publishers/global/plugins/jquery-1.11.0.min.js" type="text/javascript"></script>
</head>
<body>
<?php
$this->beginContent("@app/views/layouts/_header.php");
$this->endContent();
?>

<!-- END HEADER -->
<!-- BEGIN PAGE CONTAINER -->
<div class="page-container">
    <div class="page-content">
        <div class="container">
        <!-- BEGIN PAGE BREADCRUMB -->
			<?= Breadcrumbs::widget([
				'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
				'itemTemplate'=>'{link} <i class="fa fa-circle"></i> ',
			]) ?>
            <?=$content?>
        </div>
    </div>
</div>
<!-- END PAGE CONTAINER -->
<!-- BEGIN PRE-FOOTER -->
<div class="page-prefooter">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12 footer-block">
                <h2>About</h2>
                <p>
                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam dolore.
                </p>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12 footer-block">
                <h2>Contacts</h2>
                <address class="margin-bottom-40">
                    Email: <a href="mailto:support@maxppi.com">support@maxppi.com</a>
                </address>
            </div>
        </div>
    </div>
</div>
<!-- END PRE-FOOTER -->
<!-- BEGIN FOOTER -->
<div class="page-footer">
    <div class="container">
        2014 &copy; MaxPPI. All Rights Reserved.
    </div>
</div>
<div class="scroll-to-top">
    <i class="icon-arrow-up"></i>
</div>
<!-- END FOOTER -->
<!-- BEGIN JAVASCRIPTS (Load javascripts at bottom, this will reduce page load time) -->
<!-- BEGIN CORE PLUGINS -->
<!--[if lt IE 9]>
<script src="/publishers/global/plugins/respond.min.js"></script>
<script src="/publishers/global/plugins/excanvas.min.js"></script>
<![endif]-->
<!--<script src="/publishers/global/plugins/jquery-1.11.0.min.js" type="text/javascript"></script>-->
<!--<script src="/publishers/global/plugins/jquery-migrate-1.2.1.min.js" type="text/javascript"></script>-->
<!-- IMPORTANT! Load jquery-ui-1.10.3.custom.min.js before bootstrap.min.js to fix bootstrap tooltip conflict with jquery ui tooltip -->

<script type="text/javascript">
    jQuery(document).ready(function() {
        Metronic.init(); // init metronic core componets
//        Layout.init(); // init layout
//        Demo.init(); // init demo(theme settings page)
//        Index.init(); // init index page
//        Tasks.initDashboardWidget(); // init tash dashboard widget
    });
</script>


<script src="/publishers/global/plugins/jquery-ui/jquery-ui-1.10.3.custom.min.js" type="text/javascript"></script>
<script src="/publishers/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="/publishers/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
<script src="/publishers/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<script src="/publishers/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
<script src="/publishers/global/plugins/jquery.cokie.min.js" type="text/javascript"></script>
<script src="/publishers/global/plugins/uniform/jquery.uniform.min.js" type="text/javascript"></script>
<script src="/publishers/global/scripts/metronic.js" type="text/javascript"></script>
<script src="/publishers/admin/layout3/scripts/layout.js" type="text/javascript"></script>
<!-- END CORE PLUGINS -->
<!-- END PAGE LEVEL SCRIPTS -->
</body>

</html>
