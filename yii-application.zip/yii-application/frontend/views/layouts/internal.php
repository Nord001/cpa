<?php
/**
 * @var $this \yii\web\View
 * @var $content string
 */
?>
<?php $this->beginContent('@app/views/layouts/public.php'); ?>
    <div class="slider slider-internal">
        <div class="head-text">
            <a class='main'><?=$this->context->topTitle?> - </a><a><?=$this->context->topText?></a>
        </div>
    </div>
    <div id="content">
        <div class="content">
            <?=$content?>
            <div class="bottom-sea"></div><div class="bottom-green"></div><div class="bottom-red"></div>
        </div>
    </div>
<?php $this->endContent(); ?>
