<?php
/* @var $this \yii\web\View */

?>
<?php $this->beginContent('@app/views/layouts/public.php'); ?>
        <div class="slider">
            <ul id="carousel">
                <li>
                    <a href="/site/page?view=publishers">
                        <img src="/img/slider_1.jpg" alt="Publishers" />
                    </a>
                    <div class="shadow"></div>
                    <div class="transform-line shadow-line"></div>
                    <div class="transform-line black-line"></div>
                    <div class="black-line-small"><a href="/site/page?view=publishers">Publishers</a></div>
                    <div class="text">
                        <p class="text-slider">Start making money from your software installations</p>
                        <p class="text-slider">Monetize your siftware with the most competitive PPI rates and trusted brands</p>
                    </div>
                </li>
                <li>
                    <a href="/site/page?view=advertisers">
                        <img src="/img/slider_2.jpg" alt="Advertisers" />
                    </a>
                    <div class="shadow"></div>
                    <div class="transform-line shadow-line"></div>
                    <div class="transform-line black-line"></div>
                    <div class="black-line-small"><a href="/site/page?view=advertisers">Advertisers</a></div>
                    <div class="text">
                        <p class="text-slider">Reach your targeted audience with leading distribution network</p>
                        <p class="text-slider">Boost your ROI with MAX PPI trusted distribution platform</p>
                    </div>
                </li>
                <li>
                    <a href="/site/page?view=works">
                        <img src="/img/slider_3.jpg" alt="How it works" />
                    </a>
                    <div class="shadow"></div>
                    <div class="transform-line shadow-line"></div>
                    <div class="transform-line black-line"></div>
                    <div class="black-line-small"><a href="/site/page?view=works">How it works</a></div>
                    <div class="text">
                        <p class="text-slider">Learn what we do that makes both our software publishers and their users happy and allow our advertisers to reach additional targeted audiences.</p>
                    </div>
                </li>
            </ul>
            <div class="row-blocks">
                <div class="block-span">
                    <a href="/site/page?view=publishers"><img src="/img/publishers.jpg"/></a>
                    <div class="text-block publisher-block">
                        <p class="head">software publishers</p>
                        <p>Learn how we assist software developers better monetize their software download installations and increase their bottom line revenues!</p>
                    </div>
                </div>
                <div class="block-span span-second">
                    <a href="/site/page?view=advertisers"><img src="/img/software.jpg"/></a>
                    <div class="text-block software-block">
                        <p class="head">software advertisers</p>
                        <p>Learn how we increase your software distribution by offering it along with complementary products.</p>
                    </div>
                    
                </div>
                <div class="block-span">
                    <a href="/site/page?view=works"><img src="/img/how_works.jpg"/></a>
                    <div class="text-block how-block">
                        <p class="head">how it works</p>
                        <p>Learn what we do that makes both our software publishers and their users happy and allow our advertisers to reach additional targeted audiences.</p>
                    </div>
                    
                </div>
            </div>
        </div>
    
	<div id="content">
            <?=$content?>
        </div>
    
    
        <script src="/js/jquery.jcarousel.min.js"></script>
        <script type="text/javascript">
            function CarouselMouseWheel(event, delta) {
                if (delta < 0)
                {
                    $('.jcarousel-next-horizontal').trigger('click');  
                }
                else if (delta > 0)
                { 
                    $('.jcarousel-prev-horizontal').trigger('click');
                }
            }
            jQuery.easing['easeInOutCirc'] = function (x, t, b, c, d) {
                        if ((t/=d/2) < 1) return -c/2 * (Math.sqrt(1 - t*t) - 1) + b;
                        return c/2 * (Math.sqrt(1 - (t-=2)*t) + 1) + b;
                },
            $(document).ready(function() {
                $('#carousel').jcarousel({
                    wrap: 'circular',
                    auto: 10,
                    mouseWheel: true,
                    easing: 'easeInOutCirc',
                    animation: 1500,
                    buttonNextHTML: '<span class="slider-next"></span>',
                    buttonPrevHTML: '<span class="slider-prev"></span>',
                    scroll: 1,
                }).mousewheel(function (event, delta){
                CarouselMouseWheel(event, delta);
                return false;
            });

            });
        </script>
<?php $this->endContent(); ?>
