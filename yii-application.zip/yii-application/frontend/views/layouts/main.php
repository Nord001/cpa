<?
use yii\helpers\Html;
use yii\helpers\Url;

/**
 * @var $this    \yii\web\View
 * @var $content string
 */
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en-US">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta name="language" content="en"/>
	<link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="/css/style.css"/>
	<link rel="stylesheet" type="text/css" href="/css/popup.css"/>
	<!--<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600&subset=latin,cyrillic' rel='stylesheet' type='text/css'>-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
	<script type="text/javascript" src="/publishers/global/plugins/jquery-ui/jquery-ui-1.10.3.custom.min.js"></script>
	<title><?= Html::encode($this->title); ?></title>
	<?= $this->head(); ?>
</head>
<body>

<div class="wrapper">
	<div class="header">
		<header>
			<h1>
				<a href="/" class="logo"></a>
			</h1>

			<nav>
				<?php
				echo \yii\widgets\Menu::widget(
					[
						'items' => [
							[
								'label' => 'Home',
								'url'   => ['/site/index']
							],
							[
								'label' => 'Publishers',
								'url'   => [
									'/site/page',
									'view' => 'publishers'
								]
							],
							[
								'label' => 'Advertisers',
								'url'   => [
									'/site/page',
									'view' => 'advertisers'
								]
							],
							[
								'label' => 'How it Works',
								'url'   => [
									'/site/page',
									'view' => 'works'
								]
							],
							[
								'label' => 'FAQ',
								'url'   => [
									'/site/page',
									'view' => 'faq'
								]
							],
							[
								'label' => 'About Us',
								'url'   => [
									'/site/page',
									'view' => 'about'
								]
							],
							//                                array('label'=>'Careers', 'url'=>array('/site/page', 'view'=>'careers')),
							[
								'label' => 'Contact',
								'url'   => ['/site/contact']
							],
							[
								'label'       => 'Log In',
								'url'         => URL::to(['#']),
								'visible'     => Yii::$app->user->getIsGuest(),
								'options' => ["id" => "login-bttn"]
							],
							[
								'label'   => 'Logout ('.\yii::$app->user->getIdentity()->username.')',
								'url'     => ['/site/logout'],
								'visible' => !Yii::$app->user->getIsGuest()
							]
						],
					]
				); ?>
			</nav>
		</header>
	</div>
	<div id="content">
		<?=$content?>
	</div>


	<div class="footer">
		<div class="wrap">
			<div class="logo"></div>
			<div class="row copy">
				<p>Copyright &copy;2011-<?php echo date('Y'); ?> by Maxppi, All Rights Reserved Worldwide. </p>
			</div>
			<div class="row">
				<ul>
					<li><a href="/site/page?view=policy">Privacy Policy & Terms of Use</a></li>
					<li><a href="/site/contact">Contact Us</a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<!-- wrapper -->
<div class="dialog-ower" onclick='$(".dialog-ower").hide();$("#login-page").dialog("close");'>
	<div id="login-page">
		<div class="form-dialog">

			<div class='close-dialog' onclick='$(".dialog-ower").hide();$("#login-page").dialog("close");'>Close</div>
			<form id="login-form" action="http://publisher.main2" method="post">
				<div class="control-group">
					<div class="controls">
						<input class="span5" placeholder="Email" name="LoginForm[username]" id="LoginForm_username"
							   type="text"/>

						<div class="alert alert-error" id="LoginForm_username_em_" style="display:none"></div>
					</div>
				</div>

				<div class="control-group">
					<div class="controls">
						<input class="span5" placeholder="Password" name="LoginForm[password]" id="LoginForm_password"
							   type="password"/>

						<div class="alert alert-error" id="LoginForm_password_em_" style="display:none"></div>
					</div>
				</div>

				<div class="form-inline">
					<input id="ytLoginForm_rememberMe" type="hidden" value="0" name="LoginForm[rememberMe]"/><input
						name="LoginForm[rememberMe]" id="LoginForm_rememberMe" value="1" type="checkbox"/> <label
						class="control-label" for="LoginForm_rememberMe">Remember me</label> <input
						class="btn btn-large btn-login" type="submit" name="yt1" value="Sign in"/></div>

			</form>
		</div>
		<div class="forgot">
			<a href="/site/countact">Forgot password?</a>
			<span class="reg"><span>No account?</span> <a href="/site/register">Sign up!</a></span>
		</div>
	</div>
</div>
<script type="text/javascript">
	/*<![CDATA[*/
	jQuery(function ($) {
		$("#login-bttn").click(function () {
			$(".dialog-ower").show();
			$("#login-page").dialog();
			return false;
		});
	});
	/*]]>*/
</script>
</body>
</html>
