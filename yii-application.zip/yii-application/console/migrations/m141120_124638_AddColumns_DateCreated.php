<?php
use yii\db\Schema;
use yii\db\Migration;

class m141120_124638_AddColumns_DateCreated extends Migration {

	const DATE_CREATED = 'date_created';

	public function up () {
		$this->addColumn('{{%installer_connects}}', self::DATE_CREATED, Schema::TYPE_TIMESTAMP.' WITH TIME ZONE');
		$this->addColumn('{{%installer_installs}}', self::DATE_CREATED, Schema::TYPE_TIMESTAMP.' WITH TIME ZONE');
		$this->addColumn('{{%installer_finishes}}', self::DATE_CREATED, Schema::TYPE_TIMESTAMP.' WITH TIME ZONE');
	}

	public function down () {
		$this->dropColumn('{{%installer_connects}}', self::DATE_CREATED);
		$this->dropColumn('{{%installer_installs}}', self::DATE_CREATED);
		$this->dropColumn('{{%installer_finishes}}', self::DATE_CREATED);
	}
}
