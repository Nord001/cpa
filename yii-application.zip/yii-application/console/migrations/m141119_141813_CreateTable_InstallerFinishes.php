<?php
use yii\db\Schema;
use yii\db\Migration;

class m141119_141813_CreateTable_InstallerFinishes extends Migration {

	const TABLE_NAME = '{{%installer_finishes}}';

	public function up () {
		$this->createTable(
			self::TABLE_NAME,
			[
				'id'                => Schema::TYPE_PK,
				'click_id'          => Schema::TYPE_STRING,
				'user_id'           => Schema::TYPE_INTEGER,
				'soft_name'         => Schema::TYPE_STRING,
				'guid'              => Schema::TYPE_STRING,
				'hdd_serial_number' => Schema::TYPE_STRING,
				'softs_id'          => Schema::TYPE_INTEGER,
			]
		);
		$comments = [
			'{{%installer_finishes}}.click_id'          => 'Уникальный идентификатор перехода',
			'{{%installer_finishes}}.user_id'           => 'ID вебматера, от которого пришел трафик',
			'{{%installer_finishes}}.soft_name'         => 'Имя отданного файла',
			'{{%installer_finishes}}.guid'              => 'Глобальный уникальный идентификатор',
			'{{%installer_finishes}}.hdd_serial_number' => 'Серийный номер жесткого диска',
			'{{%installer_finishes}}.softs_id'          => 'ID установленных софтов',
		];
		foreach($comments as $field => $comment) {
			$sql = 'COMMENT ON COLUMN '.$field.' IS \''.$comment.'\'';
			$this->execute($sql);
		}
		$this->addForeignKey('fk_finish_publisher', self::TABLE_NAME, 'user_id', '{{%users}}', 'id');
	}

	public function down () {
		$this->dropTable(self::TABLE_NAME);
	}
}
