<?php
use yii\db\Schema;
use yii\db\Migration;

class m141118_165442_CreateTable_ProfitStat extends Migration {

	public function up () {
		$this->createTable(
			'{{%profit_stats}}',
			[
				'user_id'    => Schema::TYPE_INTEGER,
				'landing_id' => Schema::TYPE_INTEGER,
				'amount'     => Schema::TYPE_DECIMAL.'(10,2)',
			]
		);
		/**
		 * http://webcrunch.ru/library/development/postgres/indexescomposite/
		 */
		$this->addPrimaryKey(
			'pkey',
			'{{%profit_stats}}',
			[
				'user_id',
				'landing_id'
			]
		);
		$this->addForeignKey('fk_profit_publisher', '{{%profit_stats}}', 'user_id', '{{%users}}', 'id');
		$this->addForeignKey('fk_profit_landing', '{{%profit_stats}}', 'landing_id', '{{%landings}}', 'id');
	}

	public function down () {
		$this->dropForeignKey('fk_profit_publisher', '{{%profit_stats}}');
		$this->dropForeignKey('fk_profit_landing', '{{%profit_stats}}');
		$this->dropTable('{{%profit_stats}}');
	}
}
