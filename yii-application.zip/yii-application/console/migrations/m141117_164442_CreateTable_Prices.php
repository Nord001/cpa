<?php
use yii\db\Schema;
use yii\db\Migration;

class m141117_164442_CreateTable_Prices extends Migration {

	public function up () {
		$this->createTable(
			'{{%prices}}',
			[
				'id'         => Schema::TYPE_PK,
				'offer_id'   => Schema::TYPE_INTEGER,
				'country_id' => Schema::TYPE_STRING.' NOT NULL',
				'amount'     => Schema::TYPE_DECIMAL.'(10,4) NOT NULL',
			]
		);
		$this->addForeignKey('fk_prices_offer', '{{%prices}}', 'offer_id', '{{%offers}}', 'id', 'CASCADE', 'CASCADE');
	}

	public function down () {
		$this->dropForeignKey('fk_prices_offer', '{{%prices}}');
		$this->dropTable('{{%prices}}');
	}
}
