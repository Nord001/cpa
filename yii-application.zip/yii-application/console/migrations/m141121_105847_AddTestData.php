<?php
use yii\db\Schema;
use yii\db\Migration;

class m141121_105847_AddTestData extends Migration {

	public function safeUp () {
		$this->insert(
			'{{%landings}}',
			[
				'id'          => 17,
				'url'         => 'http://downloadtrace.com',
				'country_id'  => 1,
				'platform_id' => 1
			]
		);
		$this->insert(
			'{{%offers}}',
			[
				'id'                 => 2,
				'name'               => 'FakeOffer',
				'is_fix_countries'   => 0,
				'is_partial_install' => 1,
			]
		);
		$this->insert(
			'{{%users}}',
			[
				'id'       => 225,
				'login'    => 'VasyaPupkin',
				'password' => 'sdljf',
				'role'     => 1,
			]
		);
		$this->insert(
			'{{%publishers}}',
			[
				'id'          => 2,
				'user_id'     => 225,
				'first_name'  => 'Шуруп',
				'middle_name' => 'Митрофанович',
				'last_name'   => 'Кузякин',
				'email'       => '1@1.ru',
				'back_url'    => 'http://yahoo.com',
			]
		);
		$this->insert(
			'{{%softs}}',
			[
				'user_id'       => 225,
				'is_active'     => 1,
				'platform_id'   => 1,
				'country_id'    => 1,
				'limit_per_day' => 100,
				'date_close'    => '2015-01-10 16:55:28',
			]
		);
		$this->insert(
			'{{%softs}}',
			[
				'user_id'       => 225,
				'is_active'     => 1,
				'platform_id'   => 1,
				'country_id'    => 1,
				'limit_per_day' => 100,
				'date_close'    => '2015-01-10 16:55:28',
			]
		);
	}

	public function safeDown () {

	}
}
