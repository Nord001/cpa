<?php
use yii\db\Schema;
use yii\db\Migration;

class m141117_172642_CreateTable_Softs extends Migration {

	public function up () {
		$this->createTable(
			'{{%softs}}',
			[
				'id'            => Schema::TYPE_PK,
				'user_id' => Schema::TYPE_INTEGER,
				'date_created'  => Schema::TYPE_TIMESTAMP.' WITH TIME ZONE',
				'is_active'     => Schema::TYPE_BOOLEAN,
				'platform_id'   => Schema::TYPE_INTEGER,
				'country_id'    => Schema::TYPE_INTEGER,
				'limit_per_day' => Schema::TYPE_INTEGER,
				'date_close'    => Schema::TYPE_TIMESTAMP.' WITH TIME ZONE',
			]
		);

		$this->addForeignKey('fk_soft_advertiser', '{{%softs}}', 'user_id', '{{%users}}', 'id', 'CASCADE', 'CASCADE');
	}

	public function down () {
		$this->dropTable('{{%softs}}');
	}
}
