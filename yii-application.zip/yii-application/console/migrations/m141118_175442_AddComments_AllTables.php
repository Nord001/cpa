<?php
use yii\db\Schema;
use yii\db\Migration;

class m141118_175442_AddComments_AllTables extends Migration {

	public function up () {
		$comments = [
			'{{%advertisers}}.is_active'     => 'Активен ли рекламодатель',
			'{{%advertisers}}.hold'          => 'Холдовый период',
			'{{%advertisers}}.date_created'  => 'Дата создания',

			'{{%landings}}.url'              => 'URL лэндинга',
			'{{%landings}}.country_id'       => 'ID страны',
			'{{%landings}}.platform_id'      => 'ID платформы',
			'{{%landings}}.date_created'     => 'Дата создания',

			'{{%offers}}.name'               => 'Имя',
			'{{%offers}}.is_fix_countries'   => 'Только для фиксированных стран',
			'{{%offers}}.is_partial_install' => 'Оплачивается ли частичная учтановка?',

			'{{%prices}}.offer_id'           => 'ID оффера',
			'{{%prices}}.country_id'         => 'ID страны',
			'{{%prices}}.amount'             => 'Стоимость лида',

			'{{%profit_stats}}.user_id'      => 'ID паблишера',
			'{{%profit_stats}}.landing_id'   => 'ID лэндинга',
			'{{%profit_stats}}.amount'       => 'Значение',

			'{{%publishers}}.first_name'     => 'Имя',
			'{{%publishers}}.last_name'      => 'Фамилия',
			'{{%publishers}}.middle_name'    => 'Отчество',
			'{{%publishers}}.email'          => 'E-mail',
			'{{%publishers}}.back_url'       => 'Back URL',

			'{{%softs}}.user_id'             => 'ID рекламодателя',
			'{{%softs}}.date_created'        => 'Дата создания',
			'{{%softs}}.is_active'           => 'Активен ли софт',
			'{{%softs}}.platform_id'         => 'ID платформы',
			'{{%softs}}.country_id'          => 'ID страны',
			'{{%softs}}.limit_per_day'       => 'Лимит в день, null - без лимита',
			'{{%softs}}.date_close'          => 'Дата закрытия, null - дата отсутствует',

			'{{%users}}.login'               => 'Имя пользователя',
			'{{%users}}.password'            => 'Хэш пароля',
			'{{%users}}.role'                => 'Роль',
			'{{%users}}.date_created'        => 'Дата создания',
		];
		foreach($comments as $field => $comment) {
			$sql = 'COMMENT ON COLUMN '.$field.' IS \''.$comment.'\'';
			$this->execute($sql);
		}
	}

	public function down () {
	}
}
