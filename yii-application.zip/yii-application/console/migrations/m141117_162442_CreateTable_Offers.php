<?php
use yii\db\Schema;
use yii\db\Migration;

class m141117_162442_CreateTable_Offers extends Migration {

	public function up () {
		$this->createTable(
			'{{%offers}}',
			[
				'id'                 => Schema::TYPE_PK,
				'name'               => Schema::TYPE_STRING.' NOT NULL',
				'is_fix_countries'   => Schema::TYPE_BOOLEAN.' NOT NULL',
				'is_partial_install' => Schema::TYPE_BOOLEAN.' NOT NULL',
			]
		);
	}

	public function down () {
		$this->dropTable('{{%offers}}');
	}
}
