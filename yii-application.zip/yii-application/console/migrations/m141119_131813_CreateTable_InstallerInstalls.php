<?php
use yii\db\Schema;
use yii\db\Migration;

class m141119_131813_CreateTable_InstallerInstalls extends Migration {

	const TABLE_NAME = '{{%installer_installs}}';

	public function up () {
		$this->createTable(
			self::TABLE_NAME,
			[
				'id'                => Schema::TYPE_PK,
				'click_id'          => Schema::TYPE_STRING,
				'user_id'           => Schema::TYPE_INTEGER,
				'soft_name'         => Schema::TYPE_STRING,
				'guid'              => Schema::TYPE_STRING,
				'hdd_serial_number' => Schema::TYPE_STRING,
				'soft_id'           => Schema::TYPE_INTEGER,
			]
		);
		$comments = [
			'{{%installer_installs}}.click_id'          => 'Уникальный идентификатор перехода',
			'{{%installer_installs}}.user_id'           => 'ID вебматера, от которого пришел трафик',
			'{{%installer_installs}}.soft_name'         => 'Имя отданного файла',
			'{{%installer_installs}}.guid'              => 'Глобальный уникальный идентификатор',
			'{{%installer_installs}}.hdd_serial_number' => 'Серийный номер жесткого диска',
			'{{%installer_installs}}.soft_id'           => 'ID установленной программы',
		];
		foreach($comments as $field => $comment) {
			$sql = 'COMMENT ON COLUMN '.$field.' IS \''.$comment.'\'';
			$this->execute($sql);
		}
		$this->addForeignKey('fk_install_soft', self::TABLE_NAME, 'soft_id', '{{%softs}}', 'id');
		$this->addForeignKey('fk_install_publisher', self::TABLE_NAME, 'user_id', '{{%users}}', 'id');
	}

	public function down () {
		$this->dropTable(self::TABLE_NAME);
	}
}
