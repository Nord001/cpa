<?php
use yii\db\Schema;
use yii\db\Migration;

class m141119_131813_CreateTable_InstallerConnects extends Migration {

	const TABLE_NAME = '{{%installer_connects}}';

	public function up () {
		$this->createTable(
			self::TABLE_NAME,
			[
				'id'                    => Schema::TYPE_PK,
				'click_id'              => Schema::TYPE_STRING,
				'user_id'               => Schema::TYPE_INTEGER,
				'soft_name'             => Schema::TYPE_STRING,
				'guid'                  => Schema::TYPE_STRING,
				'hdd_serial_number'     => Schema::TYPE_STRING,
				'net_framework_version' => Schema::TYPE_STRING,
				'os_version'            => Schema::TYPE_STRING,
				'count_softs'           => Schema::TYPE_INTEGER,
			]
		);
		$comments = [
			'{{%installer_connects}}.click_id'              => 'Уникальный идентификатор перехода',
			'{{%installer_connects}}.user_id'               => 'ID вебматера, от которого пришел трафик',
			'{{%installer_connects}}.soft_name'             => 'Имя отданного файла',
			'{{%installer_connects}}.guid'                  => 'Глобальный уникальный идентификатор',
			'{{%installer_connects}}.hdd_serial_number'     => 'Серийный номер жесткого диска',
			'{{%installer_connects}}.net_framework_version' => 'Версия .NET Framework',
			'{{%installer_connects}}.os_version'            => 'Версия ОС',
			'{{%installer_connects}}.count_softs'           => 'Количество отданного спонсорского софта',
		];
		foreach($comments as $field => $comment) {
			$sql = 'COMMENT ON COLUMN '.$field.' IS \''.$comment.'\'';
			$this->execute($sql);
		}
		$this->addForeignKey('fk_connect_publisher', self::TABLE_NAME, 'user_id', '{{%users}}', 'id');
	}

	public function down () {
		$this->dropTable(self::TABLE_NAME);
	}
}
