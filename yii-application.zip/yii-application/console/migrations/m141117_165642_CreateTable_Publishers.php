<?php
use yii\db\Schema;
use yii\db\Migration;

class m141117_165642_CreateTable_Publishers extends Migration {

	public function up () {
		$this->createTable(
			'{{%publishers}}',
			[
				'id'          => Schema::TYPE_PK,
				'user_id'     => Schema::TYPE_INTEGER,
				'first_name'  => Schema::TYPE_STRING,
				'middle_name' => Schema::TYPE_STRING,
				'last_name'   => Schema::TYPE_STRING,
				'email'       => Schema::TYPE_STRING,
				'back_url'    => Schema::TYPE_STRING,
			]
		);
		$this->addForeignKey('fk_publisher_user', '{{%publishers}}', 'user_id', '{{%users}}', 'id', 'CASCADE', 'CASCADE');
	}

	public function down () {
		$this->dropTable('{{%publishers}}');
	}
}
