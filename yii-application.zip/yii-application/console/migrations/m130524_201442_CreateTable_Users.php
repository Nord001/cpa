<?php
use yii\db\Schema;
use yii\db\Migration;

class m130524_201442_CreateTable_Users extends Migration {

	public function up () {
		$this->createTable(
			'{{%users}}',
			[
				'id'           => Schema::TYPE_PK,
				'login'        => Schema::TYPE_STRING.' NOT NULL',
				'password'     => Schema::TYPE_STRING.' NOT NULL',
				'role'         => Schema::TYPE_INTEGER.' NOT NULL',
				'date_created' => Schema::TYPE_TIMESTAMP.' WITH TIME ZONE',
			]
		);
	}

	public function down () {
		$this->dropTable('{{%users}}');
	}
}
