<?php
use yii\db\Schema;
use yii\db\Migration;

class m141117_151442_CreateTable_Advertisers extends Migration {

	public function up () {
		$this->createTable(
			'{{%advertisers}}',
			[
				'id'           => Schema::TYPE_PK,
				'company_name' => Schema::TYPE_STRING.' NOT NULL',
				'date_created' => Schema::TYPE_TIMESTAMP.' WITH TIME ZONE',
				'is_active'    => Schema::TYPE_BOOLEAN.' NOT NULL',
				'hold'         => Schema::TYPE_INTEGER.' NOT NULL',
			]
		);
	}

	public function down () {
		$this->dropTable('{{%advertisers}}');
	}
}
