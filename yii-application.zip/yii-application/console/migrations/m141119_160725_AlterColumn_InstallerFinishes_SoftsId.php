<?php
use yii\db\Schema;
use yii\db\Migration;

class m141119_160725_AlterColumn_InstallerFinishes_SoftsId extends Migration {

	public function up () {
		$this->alterColumn('{{%installer_finishes}}', 'softs_id', Schema::TYPE_STRING);
	}

	public function down () {
		$this->alterColumn('{{%installer_finishes}}', 'softs_id', Schema::TYPE_INTEGER);
	}
}
