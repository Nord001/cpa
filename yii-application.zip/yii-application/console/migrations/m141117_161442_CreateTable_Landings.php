<?php
use yii\db\Schema;
use yii\db\Migration;

class m141117_161442_CreateTable_Landings extends Migration {

	public function up () {
		$this->createTable(
			'{{%landings}}',
			[
				'id'           => Schema::TYPE_PK,
				'url'          => Schema::TYPE_STRING.' NOT NULL',
				'country_id'   => Schema::TYPE_INTEGER.' NOT NULL',
				'platform_id'  => Schema::TYPE_INTEGER.' NOT NULL',
				'date_created' => Schema::TYPE_TIMESTAMP.' WITH TIME ZONE',
			]
		);
	}

	public function down () {
		$this->dropTable('{{%landings}}');
	}
}
