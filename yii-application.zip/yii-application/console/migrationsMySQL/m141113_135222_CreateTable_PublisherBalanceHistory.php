<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_135222_CreateTable_PublisherBalanceHistory extends Migration {

	private $tableName = '{{%publisher_balance_history}}';

	public function up () {
		$tableOptions = null;
		$this->createTable(
			$this->tableName,
			[
				'id'           => Schema::TYPE_PK,
				'publisher_id' => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'dt'           => Schema::TYPE_TIMESTAMP.' NOT NULL DEFAULT CURRENT_TIMESTAMP',
				'about'        => Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'amount'       => Schema::TYPE_DECIMAL.'(12,6) NOT NULL DEFAULT "0.0"',
				'balance'      => Schema::TYPE_DECIMAL.'(12,6) NOT NULL DEFAULT "0.0"',
			]
		);
	}

	public function down () {
		$this->dropTable($this->tableName);
	}
}
