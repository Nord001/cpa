<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_134642_CreateTable_CountriesStat extends Migration {

	private $tableName = '{{%countries_stat}}';

	public function up () {
		$tableOptions = null;
		$this->createTable(
			$this->tableName,
			[
				'id'       => Schema::TYPE_PK,
				'dt'       => Schema::TYPE_DATETIME.' NOT NULL',
				'country'  => Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'show'     => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'uniq'     => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'download' => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'run'      => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'install'  => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'success'  => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
			]
		);
		$this->createIndex('dt', $this->tableName, 'dt');
	}

	public function down () {
		$this->dropTable($this->tableName);
	}
}
