<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_134842_CreateTable_ViewsStat extends Migration {

	private $tableName = '{{%views_stat}}';

	public function up () {
		$tableOptions = null;
		$this->createTable(
			$this->tableName,
			[
				'id'       => Schema::TYPE_PK,
				'dt'       => Schema::TYPE_DATETIME.' NOT NULL',
				'view_id'  => Schema::TYPE_INTEGER.' NOT NULL',
				'show'     => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'uniq'     => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'download' => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'run'      => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'install'  => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'success'  => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
			]
		);
		$this->createIndex('dt', $this->tableName, 'dt');
		$this->createIndex('view', $this->tableName, 'view_id');
	}

	public function down () {
		$this->dropTable($this->tableName);
	}
}
