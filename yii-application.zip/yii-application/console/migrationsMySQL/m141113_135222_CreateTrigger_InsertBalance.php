<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_135222_CreateTrigger_InsertBalance extends Migration {

	private $tableHistoryName = '{{%publisher_balance_history}}';
	private $tablePublisherName = '{{%publisher_balance_history}}';
	private $triggerName = 'insert_balance';

	public function up () {
		$this->execute(
			"CREATE TRIGGER `".$this->triggerName."` AFTER INSERT ON ".$this->tableHistoryName."
		FOR EACH ROW BEGIN
		  UPDATE ".$this->tablePublisherName." SET balance = NEW.balance WHERE id = NEW.publisher_id;
		END"
		);
	}

	public function down () {
		$this->execute("DROP TRIGGER `".$this->triggerName."`");
	}
}
