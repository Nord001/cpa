<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_135542_CreateTable_Landing extends Migration {

	private $tableName = '{{%landing}}';

	public function up () {
		$this->createTable(
			$this->tableName,
			[
				'id'       => 'pk',
				'dt'       => Schema::TYPE_TIMESTAMP.' NOT NULL DEFAULT CURRENT_TIMESTAMP',
				'offer_id' => Schema::TYPE_INTEGER.' NOT NULL',
				'name'     => Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'url'      => Schema::TYPE_STRING.' NOT NULL',
				'flags'    => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
			]
		);
		$this->createIndex('flags', $this->tableName, 'flags', false);
	}

	public function down () {
		$this->dropTable($this->tableName);
	}
}
