<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_135842_CreateTrigger_OfferMaxPriceUpdate extends Migration {

	private $triggerName = 'offer_max_price_update';
	private $offerCountryPriceTableName = '{{%offer_country_price}}';
	private $offerTableName = '{{%offer}}';

	public function up () {
		$this->execute(
			"CREATE TRIGGER `".$this->triggerName."` AFTER UPDATE ON ".$this->offerCountryPriceTableName."
		FOR EACH ROW BEGIN
		  UPDATE ".$this->offerTableName." SET max_price = IF(OLD.price > max_price , OLD.price, max_price) WHERE id = OLD.offer_id;
		END;"
		);
	}

	public function down () {
		$this->execute("DROP TRIGGER `".$this->triggerName."`;");
	}
}
