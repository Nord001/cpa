<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_135642_CreateTable_Country extends Migration {

	private $tableName = '{{%country}}';

	public function up () {
		$this->createTable(
			$this->tableName,
			[
				'id' => Schema::TYPE_PK,
				'dt' => Schema::TYPE_TIMESTAMP.' NOT NULL DEFAULT CURRENT_TIMESTAMP',
				'name' => Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'code' => Schema::TYPE_STRING.' NOT NULL',
			]
		);
	}

	public function down () {
		$this->dropTable($this->tableName);
	}
}
