<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_135342_CreateTable_Offer extends Migration {

	private $tableName = '{{%offer}}';

	public function up () {
		$this->createTable(
			$this->tableName,
			[
				'id'=>Schema::TYPE_PK,
				'dt'=>Schema::TYPE_TIMESTAMP.' NOT NULL DEFAULT CURRENT_TIMESTAMP',
				'name'=>Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'about'=>Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'description'=>Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'countries'=>Schema::TYPE_TEXT.' NOT NULL DEFAULT ""',
				'type'=>Schema::TYPE_STRING.' NOT NULL',
				'url'=>Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'price'=>Schema::TYPE_DECIMAL.'(12,6) NOT NULL DEFAULT "0.0"',
				'reject_offer_id'=>Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'reject_url'=>Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'max_price'=>Schema::TYPE_DECIMAL.'(12,6) NOT NULL DEFAULT "0.0"',
				'flags'=>Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
			]
		);
		$this->createIndex('flags', $this->tableName, 'flags', false);
	}

	public function down () {
		$this->dropTable($this->tableName);
	}
}
