<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_135142_CreateTable_Publishers extends Migration {

	private $tableName = '{{%publisher}}';

	public function up () {
		$tableOptions = null;
		$this->createTable(
			$this->tableName,
			[
				'id'=>Schema::TYPE_PK,
				'dt_reg'=>Schema::TYPE_TIMESTAMP.' NOT NULL DEFAULT CURRENT_TIMESTAMP',
				'name'=>Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'email'=>Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'password'=>Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'balance'=>Schema::TYPE_DECIMAL.'(12,6) NOT NULL DEFAULT "0.0"',
				'flags'=>Schema::TYPE_INTEGER.'(10) NOT NULL DEFAULT "0"',
			]
		);
		$this->createIndex('email', $this->tableName, 'email', true);
		$this->createIndex('flags', $this->tableName, 'flags', false);
	}

	public function down () {
		$this->dropTable($this->tableName);
	}
}
