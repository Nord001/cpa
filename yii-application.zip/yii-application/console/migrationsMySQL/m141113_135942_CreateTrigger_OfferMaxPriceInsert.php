<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_135942_CreateTrigger_OfferMaxPriceInsert extends Migration {

	private $triggerName = 'offer_max_price_insert';
	private $offerCountryPriceTableName = '{{%offer_country_price}}';
	private $offerTableName = '{{%offer}}';

	public function up () {
		$this->execute("CREATE TRIGGER `".$this->triggerName."` AFTER INSERT ON ".$this->offerCountryPriceTableName."
		FOR EACH ROW BEGIN
		  UPDATE ".$this->offerTableName." SET max_price = IF(NEW.price > max_price , NEW.price, max_price) WHERE id = NEW.offer_id;
		END;");
	}

	public function down () {
		$this->execute("DROP TRIGGER `".$this->triggerName."`;");
	}
}
