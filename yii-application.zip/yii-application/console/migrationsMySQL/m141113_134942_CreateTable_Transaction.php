<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_134942_CreateTable_Transaction extends Migration {

	private $tableName = '{{%transaction}}';

	public function up () {
		$tableOptions = null;
		$this->createTable(
			$this->tableName,
			[
				'id'             => Schema::TYPE_PK,
				'transaction_dt' => Schema::TYPE_DATETIME.' NOT NULL',
				'view_id'        => Schema::TYPE_INTEGER.' NOT NULL',
				'ip'             => Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'country'        => Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'keyword'        => Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'aff'            => Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'success'        => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0	"',
				'clm'            => Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
			]
		);
		$this->createIndex('uniq', $this->tableName, 'transaction_dt, ip');
	}

	public function down () {
		$this->dropTable($this->tableName);
	}
}
