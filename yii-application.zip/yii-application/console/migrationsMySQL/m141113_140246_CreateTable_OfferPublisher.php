<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_140246_CreateTable_OfferPublisher extends Migration {

	private $tableName = '{{%offer_publisher}}';

	public function up () {
		$this->createTable(
			$this->tableName,
			[
				'id'           => Schema::TYPE_PK,
				'dt'           => Schema::TYPE_TIMESTAMP.' NOT NULL DEFAULT CURRENT_TIMESTAMP',
				'offer_id'     => Schema::TYPE_INTEGER.' NOT NULL',
				'publisher_id' => Schema::TYPE_INTEGER.' NOT NULL',
				'flags'        => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
			]
		);
	}

	public function down () {
		$this->dropTable($this->tableName);
	}
}
