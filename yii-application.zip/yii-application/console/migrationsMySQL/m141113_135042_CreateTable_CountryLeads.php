<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_135042_CreateTable_CountryLeads extends Migration {

	private $tableName = '{{%country_leads}}';

	public function up () {
		$tableOptions = null;
		$this->createTable(
			$this->tableName,
			[
				'country'      => Schema::TYPE_STRING.' NOT NULL PRIMARY KEY',
				'country_name' => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0	"',
				'lead'         => Schema::TYPE_DECIMAL.'(12,6) NOT NULL',
			]
		);
	}

	public function down () {
		$this->dropTable($this->tableName);
	}
}
