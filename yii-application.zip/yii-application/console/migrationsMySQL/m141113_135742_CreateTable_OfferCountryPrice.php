<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_135742_CreateTable_OfferCountryPrice extends Migration {

	private $tableName = '{{%offer_country_price}}';

	public function up () {
		$this->createTable(
			$this->tableName,
			[
				'id'       => Schema::TYPE_PK,
				'offer_id' => Schema::TYPE_INTEGER.' NOT NULL DEFAULT \'0\'',
				'price'    => Schema::TYPE_DECIMAL.'(12,6) NOT NULL DEFAULT \'0.0\'',
				'code'     => Schema::TYPE_STRING.' NOT NULL',
			]
		);
	}

	public function down () {
		$this->dropTable($this->tableName);
	}
}
