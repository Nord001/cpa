<?php
use yii\db\Schema;
use yii\db\Migration;

class m141113_134742_CreateTable_ConversionsStat extends Migration {

	private $tableName = '{{%conversions_stat}}';

	public function up () {
		$tableOptions = null;
		$this->createTable(
			$this->tableName,
			[
				'id'      => Schema::TYPE_PK,
				'dt'      => Schema::TYPE_DATETIME.' NOT NULL',
				'ip'      => Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'country' => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'keyword' => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'install' => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'success' => Schema::TYPE_INTEGER.' NOT NULL DEFAULT "0"',
				'h' =>Schema::TYPE_INTEGER.' NOT NULL',
				'offer_id' =>Schema::TYPE_INTEGER.' NOT NULL',
				'landing_id' =>Schema::TYPE_INTEGER.' NOT NULL',
				'affiliate_id' =>Schema::TYPE_INTEGER.' NOT NULL',
				'saff1' =>Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'saff2' =>Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'saff3' =>Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'saff4' =>Schema::TYPE_STRING.' NOT NULL DEFAULT ""',
				'saff5' =>Schema::TYPE_STRING.' NOT NULL DEFAULT ""',

			]
		);
		$this->createIndex('dt', $this->tableName, 'dt');
		$this->createIndex('offer', $this->tableName, 'offer_id');
		$this->createIndex('affiliate', $this->tableName, 'affiliate_id');
		$this->createIndex('landing', $this->tableName, 'landing_id');
	}

	public function down () {
		$this->dropTable($this->tableName);
	}
}
